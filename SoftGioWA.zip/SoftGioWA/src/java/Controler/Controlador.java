/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

import DAO.Ad_UsuarioDAO;
import DAO.Ad_UsuarioRolDAO;
import DAO.Cl_ClienteDAO;
import DAO.Cl_HistorialDAO;
import DAO.Cl_ProveedorDAO;
import DAO.Cl_ProductoDAO;
import DAO.Tr_TransaccionMonetariaDAO;
import DAO.Tr_AperturaCajaDAO;
import DAO.Tr_FacturaDAO;
import DAO.Ad_ComunesDAO;
import DAO.Ad_CajaDAO;
import DAO.Tr_DetalleFacturaDAO;
import Model.Ad_Usuario;
import Model.Ad_UsuarioRol;
import Model.Cl_Cliente;
import Model.Cl_Historial;
import Model.Cl_Proveedor;
import Model.Cl_Producto;
import Model.Tr_TransaccionMonetaria;
import Model.Tr_AperturaCaja;
import Model.Tr_Factura;
import Model.Tr_DetalleFactura;
import Model.Ad_Caja;
import Model.Ad_Tabla;
import Report.DetFacturaRep;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 *
 * @author gcueva
 */

public class Controlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //Inicio
    String principal = "/Principal.jsp";    
    String index = "/index.jsp";    
    String seleccionarRol = "views/seleccionarRol.jsp";
    String selectCaja = "views/selectCaja.jsp";
    //Usuarios    
    String admUsuarios = "views/admUsuarios.jsp";
    String listarUsuarios = "views/listarUsuarios.jsp";    
    String editUsuario = "views/editUsuario.jsp";   
    String listarUsuarioRol = "views/listarUsuarioRol.jsp";
    String addUsuarioRol = "views/addUsuarioRol.jsp";
    //Clientes
    String admClientes = "views/admClientes.jsp"; 
    String listarClientes = "views/listarClientes.jsp";    
    String editCliente = "views/editCliente.jsp";
    String listarHistorial = "views/listarHistorial.jsp";
    String editHistorial = "views/editHistorial.jsp";
    String listarCita = "views/listarCitas.jsp";
    String editCita = "views/editCita.jsp";
    //Proveedores
    String listarProveedores = "views/listarProveedores.jsp";    
    String editProveedor = "views/editProveedor.jsp";
    //Productos
    String listarProductos = "views/listarProductos.jsp";
    String addProducto = "views/addProducto.jsp";
    String editProducto = "views/editProducto.jsp";
    String agregarProducto = "views/agregarProducto.jsp";    
    //Transacciones
    String addTransaccionMonetaria = "views/addTransaccionMonetaria.jsp";
    String addFactura = "views/addFactura.jsp";
    String repFactura = "views/repFactura.jsp";
    String impFactura = "views/impFactura.jsp";
    //Cajas
    String adminCajas = "views/admCajas.jsp"; 
    String listarCajas = "views/listarCajas.jsp";
    String addCaja = "views/addCaja.jsp";
    String editCaja = "views/editCaja.jsp"; 
    String aperturarCaja = "views/abrirCaja.jsp"; 
    String cierreCaja = "views/cierreCaja.jsp";
    //Reportes
    String adminReportes = "views/admReportes.jsp";     
    String repVentas = "views/repVentas.jsp"; 
    String repPagos = "views/repPagos.jsp"; 
    String repTotales = "views/repTotales.jsp"; 
    String repMensual = "views/repMensual.jsp";
    String repCierres = "views/repCierres.jsp";
    String repProductos = "views/repProductos.jsp";
    String repTransferencias = "views/repTransferencias.jsp"; 
    String repTransacciones = "views/repTransacciones.jsp"; 
    String repCheques = "views/repCheques.jsp";
    //Consultas
    String adminConsultas = "views/admConsultas.jsp"; 
    String repCajas = "views/repCajas.jsp"; 
    String listarFacturas = "views/listarFacturas.jsp"; 
    String consultarProductos = "views/consProductos.jsp";
    //Clases
    Ad_Usuario usuario = new Ad_Usuario();
    Ad_UsuarioDAO usuarioDao = new Ad_UsuarioDAO();    
    Ad_UsuarioRol usuarioRol = new Ad_UsuarioRol();
    Ad_UsuarioRolDAO usuarioRolDao = new Ad_UsuarioRolDAO();    
    Cl_Cliente cliente = new Cl_Cliente();
    Cl_Historial historial = new Cl_Historial();
    Cl_ClienteDAO clienteDao = new Cl_ClienteDAO();  
    Cl_HistorialDAO historialDao = new Cl_HistorialDAO();  
    Cl_Proveedor proveedor = new Cl_Proveedor();
    Cl_ProveedorDAO proveedorDao = new Cl_ProveedorDAO();
    Cl_Producto producto = new Cl_Producto();
    Cl_ProductoDAO productoDao = new Cl_ProductoDAO();    
    Tr_TransaccionMonetaria transaccionMonetaria = new Tr_TransaccionMonetaria();
    Tr_TransaccionMonetariaDAO transaccionMonetariaDAO = new Tr_TransaccionMonetariaDAO();    
    Tr_AperturaCaja aperturaCaja = new Tr_AperturaCaja();
    Tr_AperturaCaja validaAperturaCaja = new Tr_AperturaCaja();
    Tr_AperturaCajaDAO aperturaCajaDAO = new Tr_AperturaCajaDAO();    
    Tr_Factura factura = new Tr_Factura();
    Tr_FacturaDAO facturaDAO = new Tr_FacturaDAO();    
    Ad_ComunesDAO comunes = new Ad_ComunesDAO();    
    Ad_Caja caja = new Ad_Caja();
    Ad_CajaDAO cajaDao = new Ad_CajaDAO();
    Ad_ComunesDAO comunesDAO = new Ad_ComunesDAO();
    //Clases Comunes
    Ad_Tabla tabla = new Ad_Tabla();
    //Variables
    int codUsuario;
    int rolUsuario;
    //Metodos
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String rutaBruta = this.getClass().getResource("").getPath();  
               rutaBruta = rutaBruta.substring(0, rutaBruta.length() - 26);
        String acceso = "";
        String mensaje = null;
        String error = null;
        boolean exceptionOcured =false; 
        request.getSession().setAttribute("msg",mensaje);
        request.getSession().setAttribute("err",error);
        String action = request.getParameter("accion");
        if(action.equals("Ingresar")){
            String login = request.getParameter("txtUsuario");
            String password = request.getParameter("txtPassword");
            usuario.setLogin(login);
            usuario.setPassword(password);
            try{
                codUsuario = usuarioDao.validar(usuario);
                if(codUsuario > 0){
                    request.getSession().setAttribute("login", login);
                    request.getSession().setAttribute("codLogin", codUsuario);                    
                    acceso = seleccionarRol;
                }else{                    
                    request.getSession().setAttribute("msg","Usuario o Password incorrecto.");
                    acceso = index;
                }
            }catch(Exception e){
                System.out.println("Error al validar usuario: " + e.getMessage());
                acceso = index;                
            }            
        }else if(action.equals("Entrar")){
            Integer usuarioR = Integer.parseInt(request.getParameter("txtUsuario"));
            Integer oficinaR = Integer.parseInt(request.getParameter("txtOficina"));
            Integer rolR = Integer.parseInt(request.getParameter("txtRol"));            
            usuarioRol.setUsuario(usuarioR);
            usuarioRol.setOficina(oficinaR);
            usuarioRol.setRol(rolR);            
            codUsuario = usuarioRolDao.validar(usuarioRol);
            rolUsuario = rolR;
            if(codUsuario > 0){
                request.getSession().setAttribute("oficina", oficinaR);
                request.getSession().setAttribute("rol", rolR);
                if(rolR == 1){
                    request.getSession().setAttribute("desRol", "Administrador");
                }
                else
                {
                    request.getSession().setAttribute("desRol", "Cajero");
                }                
                request.getSession().setAttribute("msg",null);
                List listarCajas = usuarioRolDao.listarCajas(usuarioRol);
                if(listarCajas.size()>0 && rolR > 1)
                {
                    acceso = selectCaja;
                }
                else
                {  
                    request.getSession().setAttribute("codCaja", "");
                    acceso = principal;
                }                
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = seleccionarRol;
            }
        }else if(action.equalsIgnoreCase("Salir")){            
             acceso = index; 
        }else if(action.equalsIgnoreCase("Continuar")){  
             request.getSession().setAttribute("codCaja", Integer.parseInt(request.getParameter("txtCaja")));
             acceso = principal; 
        }else if(action.equalsIgnoreCase("Principal")){             
             acceso = principal; 
        }else if(action.equalsIgnoreCase("admUsuarios")){                         
            if(rolUsuario == 1){
                acceso = admUsuarios;
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = principal; 
            }    
        }else if(action.equalsIgnoreCase("listarUsuarios")){
            acceso = listarUsuarios;
        }else if (action.equalsIgnoreCase("addUsuario")) {
            request.setAttribute("codigo", "0");
            acceso = editUsuario;
        }else if(action.equalsIgnoreCase("editarUsuario")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editUsuario; 
        }else if(action.equalsIgnoreCase("GuardarUsuario")){
            usuario.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            usuario.setNombre(request.getParameter("txtNombre"));
            usuario.setLogin(request.getParameter("txtLogin"));
            usuario.setPassword(request.getParameter("txtPassword"));
            if (Integer.parseInt(request.getParameter("txtCodigo"))==0)
            {usuarioDao.add(usuario);}
            else
            {usuarioDao.edit(usuario);}
            acceso = listarUsuarios;     
        }else if(action.equalsIgnoreCase("eliminarUsuario")){
            usuario.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            usuarioDao.eliminar(usuario.getCodigo());
            acceso = listarUsuarios;     
        }else if(action.equalsIgnoreCase("listarUsuarioRol")){
            acceso = listarUsuarioRol;
        }else if(action.equalsIgnoreCase("addUsuarioRol")){
            acceso = addUsuarioRol;
        }else if (action.equalsIgnoreCase("AgregarUsuarioRol")) {            
            usuarioRol.setOficina(Integer.parseInt(request.getParameter("txtOficina")));
            usuarioRol.setUsuario(Integer.parseInt(request.getParameter("txtUsuario")));
            usuarioRol.setRol(Integer.parseInt(request.getParameter("txtRol")));
            if(usuarioRol.getRol()==2)
                usuarioRol.setCaja(Integer.parseInt(request.getParameter("txtCaja")));            
            else
                usuarioRol.setCaja(0);            
            usuarioRolDao.add(usuarioRol);
            acceso = listarUsuarioRol;            
        }else if(action.equalsIgnoreCase("eliminarUsuarioRol")){
            usuarioRolDao.eliminar(Integer.parseInt(request.getParameter("usuario")), Integer.parseInt(request.getParameter("rol")),Integer.parseInt(request.getParameter("caja")));
            acceso = listarUsuarioRol;
        }else if(action.equalsIgnoreCase("admClientes")){            
            acceso = admClientes;
        }else if(action.equalsIgnoreCase("listarClientes")){
            request.getSession().setAttribute("codigoCli", "0");
            request.getSession().setAttribute("cedulaCli", "");
            request.getSession().setAttribute("nombreCli", "");
            request.getSession().setAttribute("apellidoCli","");
            acceso = listarClientes;
        }else if(action.equalsIgnoreCase("BuscarCliente")){  
            request.getSession().setAttribute("cedulaCli", request.getParameter("txtIdentificacion"));
            request.getSession().setAttribute("nombreCli", request.getParameter("txtNombre"));
            request.getSession().setAttribute("apellidoCli",request.getParameter("txtApellido"));
            acceso = listarClientes;
        }else if(action.equalsIgnoreCase("SiguienteCliente")){  
            String[] codCli = new String[10];                                    
            if(request.getParameterValues("codigoCliente")!=null)
                 codCli = request.getParameterValues("codigoCliente");             
            request.getSession().setAttribute("codigoCli", codCli[codCli.length-1]);
            request.getSession().setAttribute("cedulaCli", request.getParameter("txtIdentificacion"));
            request.getSession().setAttribute("nombreCli", request.getParameter("txtNombre"));
            request.getSession().setAttribute("apellidoCli",request.getParameter("txtApellido"));
            acceso = listarClientes;
        }else if (action.equalsIgnoreCase("addCliente")) {
            request.setAttribute("codigo", "0");
            acceso = editCliente;
        }else if(action.equalsIgnoreCase("editarCliente")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editCliente; 
        }else if(action.equalsIgnoreCase("GuardarCliente")){
            request.setCharacterEncoding("UTF-8");
            cliente.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            cliente.setIdentificacion(request.getParameter("txtIdentificacion"));
            cliente.setNombre(request.getParameter("txtNombre"));
            cliente.setApellido(request.getParameter("txtApellido"));
            cliente.setDireccion(request.getParameter("txtDireccion"));
            cliente.setTelefono(request.getParameter("txtTelefono"));
            cliente.setEmail(request.getParameter("txtEmail"));
            if (Integer.parseInt(request.getParameter("txtCodigo")) == 0)            
                clienteDao.add(cliente);            
            else            
                clienteDao.edit(cliente);                       
            acceso = listarClientes;     
        }else if(action.equalsIgnoreCase("eliminarCliente")){
            cliente.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            clienteDao.eliminar(cliente.getCodigo());
            acceso = listarClientes;     
        }else if(action.equalsIgnoreCase("listarHistorial")){
            acceso = listarHistorial;
        }else if (action.equalsIgnoreCase("addHistorial")) {
            request.setAttribute("codigo", "0");
            acceso = editHistorial;
        }else if(action.equalsIgnoreCase("editarHistorial")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editHistorial; 
        }else if(action.equalsIgnoreCase("BuscarHistorial")){  
            request.getSession().setAttribute("codigoCli", request.getParameter("txtCliente"));
            acceso = listarHistorial;
        }else if(action.equalsIgnoreCase("GuardarHistorial")){
            historial.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            historial.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
            historial.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
            historial.setCliente(Integer.parseInt(request.getParameter("txtCliente")));
            historial.setMedico(Integer.parseInt(request.getParameter("txtMedico")));
            historial.setTipo(request.getParameter("txtTipo"));
            historial.setDescripcion(request.getParameter("txtDescripcion"));           
            if (Integer.parseInt(request.getParameter("txtCodigo")) == 0)            
                historialDao.add(historial);            
            else            
                historialDao.edit(historial);                       
            acceso = listarHistorial;     
        }else if(action.equalsIgnoreCase("eliminarHistorial")){
            historial.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            historialDao.eliminar(historial.getCodigo());
            acceso = listarHistorial;     
        }else if(action.equalsIgnoreCase("listarCitas")){
            acceso = listarCita;
        }else if (action.equalsIgnoreCase("addCita")) {
            request.setAttribute("codigo", "0");
            acceso = editCita;
        }else if(action.equalsIgnoreCase("editarCita")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editCita; 
        }else if(action.equalsIgnoreCase("BuscarCita")){  
            request.getSession().setAttribute("codigoCli", request.getParameter("txtCliente"));
            acceso = listarCita;
        }else if(action.equalsIgnoreCase("listarProveedores")){
            acceso = listarProveedores;
        }else if (action.equalsIgnoreCase("addProveedor")) {
            request.setAttribute("codigo", "0");
            acceso = editProveedor;
        }else if(action.equalsIgnoreCase("editarProveedor")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editProveedor; 
        }else if(action.equalsIgnoreCase("GuardarProveedor")){
            proveedor.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            proveedor.setIdentificacion(request.getParameter("txtIdentificacion"));
            proveedor.setNombre(request.getParameter("txtNombre"));            
            proveedor.setDireccion(request.getParameter("txtDireccion"));
            proveedor.setTelefono(request.getParameter("txtTelefono"));
            proveedor.setEmail(request.getParameter("txtEmail"));
            if (Integer.parseInt(request.getParameter("txtCodigo")) == 0) 
                proveedorDao.add(proveedor);
            else
                proveedorDao.edit(proveedor);
            acceso = listarProveedores;     
        }else if(action.equalsIgnoreCase("eliminarProveedor")){
            proveedor.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            proveedorDao.eliminar(proveedor.getCodigo());
            acceso = listarProveedores;     
        }else if(action.equalsIgnoreCase("listarProductos")){
            request.getSession().setAttribute("codigoPro", "0");
            request.getSession().setAttribute("nombrePro", "");
            request.getSession().setAttribute("descripcionPro", "");            
            acceso = listarProductos;
        }else if(action.equalsIgnoreCase("BuscarProducto")){                          
            request.getSession().setAttribute("codigoPro", "0");
            request.getSession().setAttribute("nombrePro", request.getParameter("txtNombrePro"));
            request.getSession().setAttribute("descripcionPro", request.getParameter("txtDescripcionPro"));            
            acceso = listarProductos;
        }else if(action.equalsIgnoreCase("SiguienteProducto")){  
            String[] codPro = new String[10];                                    
            if(request.getParameterValues("codigoPro")!=null)
                 codPro = request.getParameterValues("codigoPro");             
            request.getSession().setAttribute("codigoPro", codPro[codPro.length-1]);
            request.getSession().setAttribute("nombrePro", request.getParameter("txtNombrePro"));
            request.getSession().setAttribute("descripcionPro", request.getParameter("txtDescripcionPro"));            
            acceso = listarProductos;
        }else if(action.equalsIgnoreCase("ConsultarProductos")){ 
            request.getSession().setAttribute("nombreConPro", request.getParameter("txtNombreConPro"));
            request.getSession().setAttribute("descripcionConPro", request.getParameter("txtDescripcionConPro"));            
            acceso = consultarProductos;
        }else if(action.equalsIgnoreCase("consProductos")){            
            request.getSession().setAttribute("nombreConPro", "");
            request.getSession().setAttribute("descripcionConPro", "");            
            acceso = consultarProductos;
        }else if(action.equalsIgnoreCase("repProductos")){            
            request.getSession().setAttribute("fechaIniRP", "");
            request.getSession().setAttribute("fechaFinRP","");             
            acceso = repProductos;
        }else if(action.equalsIgnoreCase("BuscarInventario")){    
            request.getSession().setAttribute("fechaIniRP", request.getParameter("txtFechaIniRP"));
            request.getSession().setAttribute("fechaFinRP",request.getParameter("txtFechaFinRP"));   
            acceso = repProductos;     
        }else if (action.equalsIgnoreCase("addProducto")) {
            request.setAttribute("codigo", "0");
            acceso = editProducto;
        }else if(action.equalsIgnoreCase("editarProducto")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            if(rolUsuario != 1){
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
            }
            acceso = editProducto; 
        }else if(action.equalsIgnoreCase("agregarProducto")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = agregarProducto; 
        }else if(action.equalsIgnoreCase("GuardarProducto")){
            producto.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            producto.setProducto(request.getParameter("txtProducto"));
            producto.setDescripcion(request.getParameter("txtDescripcion"));
            producto.setPrecio(Double.parseDouble(request.getParameter("txtPrecio")));
            producto.setCantidad(Double.parseDouble(request.getParameter("txtCantidad")));
            if(Integer.parseInt(request.getParameter("txtCodigo"))==0)
              productoDao.add(producto);
            else
              productoDao.edit(producto);                            
               acceso = listarProductos;     
        }else if(action.equalsIgnoreCase("AgregarProductos")){
            producto.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            producto.setProducto(request.getParameter("txtProducto"));
            producto.setDescripcion(request.getParameter("txtDescripcion"));
            producto.setPrecio(Double.parseDouble(request.getParameter("txtPrecio")));
            producto.setCantidad(Double.parseDouble(request.getParameter("txtAgregar")));
            productoDao.agregar(producto);            
            acceso = consultarProductos;            
        }else if(action.equalsIgnoreCase("eliminarProducto")){
            producto.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            productoDao.eliminar(producto.getCodigo());
            acceso = listarProductos;     
        }else if (action.equalsIgnoreCase("addTransaccionMonetaria")) {
             acceso = addTransaccionMonetaria;
        }else if (action.equalsIgnoreCase("AgregarTransaccion")) {             
             transaccionMonetaria.setTransaccion(Integer.parseInt(request.getParameter("txtTransaccion")));
             transaccionMonetaria.setCausa(Integer.parseInt(request.getParameter("txtCausa")));
             transaccionMonetaria.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             transaccionMonetaria.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
             transaccionMonetaria.setCaja(Integer.parseInt(request.getSession().getAttribute("codCaja").toString()));
             transaccionMonetaria.setValor(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             if (request.getParameter("txtCheque") != null && !request.getParameter("txtCheque").equals("")){
                 transaccionMonetaria.setCheque(Double.parseDouble(request.getParameter("txtCheque").replaceAll(",", "")));
                 transaccionMonetaria.setNumeroCheque(Integer.parseInt(request.getParameter("txtNumeroCheque")));
             } 
             else{
                 transaccionMonetaria.setCheque(0.0);
                 transaccionMonetaria.setNumeroCheque(0);
             }             
             transaccionMonetaria.setDescripcion(request.getParameter("txtDescripcion"));
             String tipoPagoTM = request.getParameter("cboxTipoPagoTM");
             if(tipoPagoTM != null) 
             {    transaccionMonetaria.setTipoPago("T"); }
             else
             {    transaccionMonetaria.setTipoPago("E"); }
             
             String estadoTM = request.getParameter("cboxEstadoTM");
             if(estadoTM != null) 
             {    transaccionMonetaria.setEstado("P"); }
             else
             {    transaccionMonetaria.setEstado("V"); }
             if(transaccionMonetariaDAO.add(transaccionMonetaria)){    
                mensaje = "Transacción Exitosa";
                request.getSession().setAttribute("msg",mensaje);
             }
             else{    
                mensaje = "Error al ejecutar la Transacción";
                request.getSession().setAttribute("msg",mensaje);
                request.getSession().setAttribute("err","S");
             }
             acceso = addTransaccionMonetaria; 
        }else if (action.equalsIgnoreCase("AgregarFactura")) {     
              try{
             Map parametros = new HashMap();
             //Transaccion Monetaria
             transaccionMonetaria.setTransaccion(100);//Transaccion Ingresos
             transaccionMonetaria.setCausa(1);//Causa Ventas
             transaccionMonetaria.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             transaccionMonetaria.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
             transaccionMonetaria.setCaja(Integer.parseInt(request.getSession().getAttribute("codCaja").toString()));
             transaccionMonetaria.setValor(Double.parseDouble(request.getParameter("txtTotal").replaceAll(",", "")));
             transaccionMonetaria.setCheque(0.0);
             transaccionMonetaria.setNumeroCheque(0);       
             //Datos Factura
             factura.setCodCliente(Integer.parseInt(request.getParameter("txtCliente")));
             factura.setCodCaja(Integer.parseInt(request.getParameter("txtCodCaja")));
             factura.setUsuario(request.getParameter("txtCajero"));
             factura.setSubtotal(Double.parseDouble(request.getParameter("txtSubtotal").replaceAll(",", "")));
             factura.setIva(Double.parseDouble(request.getParameter("txtIva").replaceAll(",", "")));
             factura.setTotal(Double.parseDouble(request.getParameter("txtTotal").replaceAll(",", ""))); 
             parametros.put("subtotal",factura.getSubtotal().toString());
             parametros.put("iva",factura.getIva().toString());
             parametros.put("total",factura.getTotal().toString());
             String estado = request.getParameter("cboxEstadoFactura");
             if(estado != null) 
             {    factura.setEstado("P"); }
             else
             {    factura.setEstado("C"); }   
             String tipoPago = request.getParameter("cboxTipoPago");
             factura.setTipoPago("E");
             transaccionMonetaria.setTipoPago("E");
             if(tipoPago != null) 
             {    factura.setTipoPago("T"); 
                  transaccionMonetaria.setTipoPago("T");}
             String tipoFactura = request.getParameter("cboxTipoFac");
             if(tipoFactura != null) 
             {    factura.setTipoPago("D"); 
                  transaccionMonetaria.setTipoPago("D");}
             //Pasamos los datos de la transaccion monetaria
              factura.setTransaccionMonetaria(transaccionMonetaria);
             //DatosCliente
             cliente.setCodigo(Integer.parseInt(request.getParameter("txtCliente")));
             cliente.setIdentificacion(request.getParameter("txtIdentificacion"));
             cliente.setNombre(request.getParameter("txtNombreCliente"));
             cliente.setApellido(request.getParameter("txtApellidoCliente"));
             cliente.setDireccion(request.getParameter("txtDireccion"));
             cliente.setTelefono(request.getParameter("txtTelefono"));
             cliente.setEmail(request.getParameter("txtEmail"));
             parametros.put("cedula",cliente.getIdentificacion());
             parametros.put("cliente",cliente.getNombre()+" "+cliente.getApellido());
             parametros.put("direccion",cliente.getDireccion());
             parametros.put("telefono",cliente.getTelefono());
             parametros.put("email",cliente.getEmail());
             Date fechaFactura = new Date();
             DateFormat hourdateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");             
             parametros.put("fecha",hourdateFormat.format(fechaFactura));
             parametros.put("caja",request.getParameter("txtCodCaja"));
             parametros.put("usuario",request.getParameter("txtCajero"));
             //Fin DatosCliente
             ArrayList<Tr_DetalleFactura> detalleFactura = new ArrayList();  
             //Reporte Factura
             DetFacturaRep detFacRep;
             List<DetFacturaRep> detFacList = new ArrayList();
             String[] codProd = new String[5];
             String[] producto = new String[5];
             String[] descripcion = new String[5];
             String[] cantidad = new String[5];
             String[] precio = new String[5];                            
             if(request.getParameterValues("codProd")!=null)
                 codProd = request.getParameterValues("codProd"); 
             if(request.getParameterValues("producto")!=null)
                 producto = request.getParameterValues("producto");
             if(request.getParameterValues("descripcion")!=null)
                 descripcion = request.getParameterValues("descripcion"); 
             if(request.getParameterValues("cantidad")!=null)
                 cantidad = request.getParameterValues("cantidad");             
             if(request.getParameterValues("precio")!=null)
                 precio = request.getParameterValues("precio");                          
             for(int i=0; i< 5;i++){
                 Tr_DetalleFactura dF = new Tr_DetalleFactura();                  
                 dF.setSecuencial(i+1);
                if(codProd[i]!=null && !codProd[i].equals(""))
                 dF.setCodigo(Integer.parseInt(codProd[i]));
                if(cantidad[i]!=null && !cantidad[i].equals(""))
                 dF.setCantidad(Double.parseDouble(cantidad[i]));
                if(precio[i]!=null && !precio[i].equals(""))
                 dF.setValor(Double.parseDouble(precio[i]));
                dF.setEstado("A");
                detalleFactura.add(dF);
                if (codProd[i]!=null && !codProd[i].equals("")){
                    int numero = i+1;
                    DecimalFormat totalF = new DecimalFormat("#.##");
                    double total = dF.getCantidad()*dF.getValor();
                    detFacRep = new DetFacturaRep(String.valueOf(numero), producto[i], descripcion[i], dF.getCantidad().toString(), dF.getValor().toString(),String.valueOf(totalF.format(total)) );
                    detFacList.add(detFacRep); 
                }
               
             }
             if(cliente.getCodigo() == 0){
                 clienteDao.add(cliente);
                 factura.setCodCliente(cliente.getCodigo());
             }             
                factura.setDetalleFactura(detalleFactura);            
                Integer codigo = facturaDAO.add(factura);  
                parametros.put("codigo",codigo.toString()); 
                String imprimir = request.getParameter("cboxImprimirFactura");
                if(imprimir != null){                
                    String path = rutaBruta+"/reports/Factura.jasper";                  
                    File reportFile = new File(path);                
                    byte[] bytes = JasperRunManager.runReportToPdf(reportFile.getPath(), parametros, new JRBeanCollectionDataSource(detFacList));
                    response.setContentType("application/x-pdf");
                    //response.setHeader("Content-disposition", "inline; filename=Factura.pdf"); //Descarga
                    response.setHeader("Content-disposition", "attachment; filename=Factura_"+codigo.toString()+".pdf");             
                    response.setContentLength(bytes.length);
                    ServletOutputStream output = response.getOutputStream();                                    
                    output.write(bytes,0,bytes.length);
                    output.flush();
                    output.close(); 
                }    
                if(codigo > 0){
                  request.getSession().setAttribute("msg","Factura Nro:"+codigo+" ingresada exitosamente");
                } 
                else{
                  request.getSession().setAttribute("msg","Error al ingresar la factura");
                  request.getSession().setAttribute("err","S");
                }
                acceso = addFactura;
             }catch(Exception e){
                acceso = addFactura; 
                request.getSession().setAttribute("mensajeError", "Error al Generar la Factura");
                System.out.println("Error al agregar la Factura: " + e.getMessage());
            }                         
        }else if (action.equalsIgnoreCase("addFactura")) {
             acceso = addFactura;
        }else if(action.equalsIgnoreCase("impFactura")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = impFactura; 
        }else if(action.equalsIgnoreCase("pagFactura")){
            factura.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            facturaDAO.pagar(factura.getCodigo());
            acceso = listarFacturas;     
        }else if(action.equalsIgnoreCase("anuFactura")){
            factura.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            facturaDAO.anular(factura.getCodigo());
            acceso = listarFacturas;     
        }else if(action.equalsIgnoreCase("ImprimirFactura")){
            try{
            Map parametros = new HashMap();
            parametros.put("codigo",request.getParameter("txtFactura"));
            parametros.put("cedula",request.getParameter("txtIdentificacion"));
            parametros.put("cliente",request.getParameter("txtNombreCliente")+" "+request.getParameter("txtApellidoCliente"));
            parametros.put("direccion",request.getParameter("txtDireccion"));
            parametros.put("telefono",request.getParameter("txtTelefono"));
            parametros.put("email",request.getParameter("txtEmail"));                      
            parametros.put("fecha",request.getParameter("txtFecha"));
            parametros.put("subtotal",request.getParameter("txtSubtotal").replaceAll(",", ""));
            parametros.put("iva",request.getParameter("txtIva").replaceAll(",", ""));
            parametros.put("total",request.getParameter("txtTotal").replaceAll(",", ""));
            parametros.put("caja",request.getParameter("txtCodCaja"));
            parametros.put("usuario",request.getParameter("txtCajero"));
            DetFacturaRep detFacRep;
            List<DetFacturaRep> detFacList = new ArrayList();
            Tr_DetalleFacturaDAO dao = new Tr_DetalleFacturaDAO();                       
            List<Tr_DetalleFactura> listDetFac = dao.listarDetalle(Integer.parseInt(request.getParameter("txtFactura")));
            
            for(int x=0;x<listDetFac.size();x++) {
                System.out.println(listDetFac.get(x).getDescripcion());                
                int numero = x+1;
                DecimalFormat totalF = new DecimalFormat("#.##");
                double total = listDetFac.get(x).getCantidad()*listDetFac.get(x).getValor();
                detFacRep = new DetFacturaRep(String.valueOf(numero), listDetFac.get(x).getEstado(), listDetFac.get(x).getDescripcion(), listDetFac.get(x).getCantidad().toString(), listDetFac.get(x).getValor().toString(),String.valueOf(totalF.format(total)) );
                detFacList.add(detFacRep);
            }           
            
            String path = rutaBruta+"/reports/Factura.jasper";                  
            File reportFile = new File(path);                
            byte[] bytes = JasperRunManager.runReportToPdf(reportFile.getPath(), parametros, new JRBeanCollectionDataSource(detFacList));
            response.setContentType("application/x-pdf");
            response.setHeader("Content-disposition", "inline; filename="+request.getParameter("txtFactura")+"_Factura.pdf");
            response.setContentLength(bytes.length);
            ServletOutputStream output = response.getOutputStream();                               
            output.write(bytes,0,bytes.length);
            output.flush();
            output.close();                  
            acceso = impFactura;            
            }catch(Exception e){
                acceso = addFactura; 
                request.getSession().setAttribute("mensajeError", "Error al Imprimir la Factura");
                System.out.println("Error al imprimir la Factura: " + e.getMessage());
            }
        }else if(action.equalsIgnoreCase("adminCajas")){            
            acceso = adminCajas;     
        }else if(action.equalsIgnoreCase("listarCajas")){            
            if(rolUsuario == 1){
                acceso = listarCajas;
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminCajas; 
            }
        }else if (action.equalsIgnoreCase("addCaja")) {
             acceso = addCaja;
        }else if (action.equalsIgnoreCase("AgregarCaja")) {            
            caja.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            caja.setNombre(request.getParameter("txtNombre"));
            caja.setOficina(Integer.parseInt(request.getParameter("txtOficina")));            
            cajaDao.add(caja);
            acceso = listarCajas;            
        }else if(action.equalsIgnoreCase("editarCaja")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editCaja; 
        }else if(action.equalsIgnoreCase("ActualizarCaja")){
            caja.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            caja.setNombre(request.getParameter("txtNombre"));
            caja.setOficina(Integer.parseInt(request.getParameter("txtOficina")));            
            cajaDao.edit(caja);
            acceso = listarCajas;     
        }else if(action.equalsIgnoreCase("eliminarCaja")){
            caja.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            cajaDao.eliminar(caja.getCodigo());
            acceso = listarCajas;     
        }else if(action.equalsIgnoreCase("aperturarCaja")){            
            acceso = aperturarCaja;     
        }else if(action.equalsIgnoreCase("cierreCaja")){            
            acceso = cierreCaja;     
        }else if (action.equalsIgnoreCase("AbrirCaja")) {             
             aperturaCaja.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             aperturaCaja.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));             
             aperturaCaja.setCaja(Integer.parseInt(request.getParameter("txtCaja")));             
             aperturaCaja.setValorApertura(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             aperturaCaja.setSaldoCaja(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             if(aperturaCajaDAO.add(aperturaCaja)){    
                mensaje = "Apertura Exitosa";
                request.getSession().setAttribute("msg",mensaje);
                request.getSession().setAttribute("codCaja", aperturaCaja.getCaja());
             }
             else{    
                mensaje = "Error en la apertura de caja";
                request.getSession().setAttribute("msg",mensaje);
                request.getSession().setAttribute("err","S");
             }             
             acceso = aperturarCaja; 
        }else if (action.equalsIgnoreCase("CerrarCaja")) {             
             aperturaCaja.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             aperturaCaja.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));             
             aperturaCaja.setCaja(Integer.parseInt(request.getParameter("txtCaja")));             
             aperturaCaja.setValorCierre(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             aperturaCaja.setSaldoCaja(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             if(aperturaCajaDAO.close(aperturaCaja)){
                 request.getSession().setAttribute("codCaja", "");  
                 mensaje = "Cierre Exitoso";
                 request.getSession().setAttribute("msg",mensaje);
             }else {         
                mensaje = "Error en el cierre de caja";
                request.getSession().setAttribute("msg",mensaje);
                request.getSession().setAttribute("err","S");
             }
                 acceso = cierreCaja; 
        }else if(action.equalsIgnoreCase("adminReportes")){ 
            acceso = adminReportes;     
        }else if(action.equalsIgnoreCase("repVentas")){ 
            if(rolUsuario == 1){
                request.getSession().setAttribute("fechaIniVen", "");
                request.getSession().setAttribute("fechaFinVen","");   
                acceso = repVentas;
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }
        }else if(action.equalsIgnoreCase("BuscarIngresos")){    
            request.getSession().setAttribute("fechaIniVen", request.getParameter("txtFechaIniI"));
            request.getSession().setAttribute("fechaFinVen",request.getParameter("txtFechaFinI"));   
            acceso = repVentas;     
        }else if(action.equalsIgnoreCase("repTransferencias")){    
            request.getSession().setAttribute("fechaIniTran", "");
            request.getSession().setAttribute("fechaFinTran","");   
            acceso = repTransferencias;     
        }else if(action.equalsIgnoreCase("BuscarTransferencias")){    
            request.getSession().setAttribute("fechaIniTran", request.getParameter("txtFechaIniT"));
            request.getSession().setAttribute("fechaFinTran",request.getParameter("txtFechaFinT"));   
            acceso = repTransferencias;     
        }else if(action.equalsIgnoreCase("repTransacciones")){    
            request.getSession().setAttribute("fechaIniTransa", "");
            request.getSession().setAttribute("fechaFinTransa","");   
            acceso = repTransacciones;     
        }else if(action.equalsIgnoreCase("BuscarTransacciones")){    
            request.getSession().setAttribute("fechaIniTransa", request.getParameter("txtFechaIniTransa"));
            request.getSession().setAttribute("fechaFinTransa",request.getParameter("txtFechaFinTransa"));   
            acceso = repTransacciones;     
        }else if(action.equalsIgnoreCase("repCheques")){    
            request.getSession().setAttribute("fechaIniCheq", "");
            request.getSession().setAttribute("fechaFinCheq","");   
            acceso = repCheques;     
        }else if(action.equalsIgnoreCase("BuscarCheques")){    
            request.getSession().setAttribute("fechaIniCheq", request.getParameter("txtFechaIniCh"));
            request.getSession().setAttribute("fechaFinCheq",request.getParameter("txtFechaFinCh"));   
            acceso = repCheques;     
        }else if(action.equalsIgnoreCase("repPagos")){  
            if(rolUsuario == 1){
                request.getSession().setAttribute("fechaIniPag", "");
                request.getSession().setAttribute("fechaFinPag","");
                acceso = repPagos;
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }
        }else if(action.equalsIgnoreCase("BuscarEgresos")){    
            request.getSession().setAttribute("fechaIniPag", request.getParameter("txtFechaIniP"));
            request.getSession().setAttribute("fechaFinPag",request.getParameter("txtFechaFinP"));   
            acceso = repPagos;     
        }else if(action.equalsIgnoreCase("repTotales")){ 
            if(rolUsuario == 1){
                request.getSession().setAttribute("fechaIniTot", "");
                request.getSession().setAttribute("fechaFinTot","");
                acceso = repTotales;
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }                 
        }else if(action.equalsIgnoreCase("BuscarTotales")){ 
            if(rolUsuario == 1){
                request.getSession().setAttribute("fechaIniTot", request.getParameter("txtFechaIniT"));
                request.getSession().setAttribute("fechaFinTot",request.getParameter("txtFechaFinT"));   
                acceso = repTotales;
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }                 
        }else if(action.equalsIgnoreCase("repMensual")){  
            if(rolUsuario == 1){
                acceso = repMensual; 
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }
        }else if(action.equalsIgnoreCase("repCierres")){ 
            if(rolUsuario == 1){
                request.getSession().setAttribute("fechaIniCie", "");
                request.getSession().setAttribute("fechaFinCie",""); 
                acceso = repCierres; 
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }
        }else if(action.equalsIgnoreCase("BuscarCierres")){ 
            if(rolUsuario == 1){
                request.getSession().setAttribute("fechaIniCie", request.getParameter("txtFechaIniC"));
                request.getSession().setAttribute("fechaFinCie",request.getParameter("txtFechaFinC")); 
                acceso = repCierres; 
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminReportes; 
            }
        }else if(action.equalsIgnoreCase("adminConsultas")){            
            acceso = adminConsultas;     
        }else if(action.equalsIgnoreCase("repCajas")){  
            if(rolUsuario == 1){
                acceso = repCajas; 
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                request.getSession().setAttribute("err","S");
                acceso = adminConsultas; 
            }
        }else if(action.equalsIgnoreCase("listarFacturas")){   
            request.getSession().setAttribute("codigoFac", "0");
            request.getSession().setAttribute("cedulaFac", "");
            request.getSession().setAttribute("fechaIniFac", "");
            request.getSession().setAttribute("fechaFinFac","");            
            acceso = listarFacturas;     
        }else if(action.equalsIgnoreCase("BuscarFactura") ){  
            request.getSession().setAttribute("codigoFac", request.getParameter("txtCodigoFac"));                       
            request.getSession().setAttribute("cedulaFac", request.getParameter("txtIdentificacion"));
            request.getSession().setAttribute("fechaIniFac", request.getParameter("txtFechaIni"));
            request.getSession().setAttribute("fechaFinFac",request.getParameter("txtFechaFin"));
            request.getSession().setAttribute("estado", request.getParameter("txtEstado"));
            acceso = listarFacturas;
        }else if(action.equalsIgnoreCase("SiguienteFactura")){  
            String[] codFac = new String[10];                                    
            if(request.getParameterValues("codigoFactura")!=null)
                 codFac = request.getParameterValues("codigoFactura");    
            request.getSession().setAttribute("codigoFac", codFac[codFac.length-1]);                   
            request.getSession().setAttribute("cedulaFac", request.getParameter("txtIdentificacion"));
            request.getSession().setAttribute("fechaIniFac", request.getParameter("txtFechaIni"));
            request.getSession().setAttribute("fechaFinFac",request.getParameter("txtFechaFin"));
            request.getSession().setAttribute("estado", request.getParameter("txtEstado"));
            acceso = listarFacturas;
        }        
        try {
             RequestDispatcher vista = request.getRequestDispatcher(acceso);
             vista.forward(request, response);
             return;            
        } catch (Exception e) {
            exceptionOcured  =true;
            System.out.println("Error al cargar la vista: " + e.getMessage()); 
        } 
        if(exceptionOcured){
               RequestDispatcher vista = request.getRequestDispatcher(acceso);
               vista.forward(request, response);
               return;
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();  
        String codigo = request.getParameter("codigo");   
        String cod = codigo.substring(0, 1);
        //A es para Busqueda De Cliente
        if(cod.equals("A")){
            String cedula = codigo.substring(2, codigo.length());
            if (!cedula.isEmpty() || !cedula.equals("null")){
                cliente = clienteDao.buscar(cedula);
                if(cliente!=null){
                    Integer codCli = 0;
                    String nombre = "";
                    String apellido = "";
                    String cedCli = "";
                    String direccion = "";
                    String telefono = "";
                    String email = "";                    
                    if(cliente.getCodigo() > 0){
                        codCli = cliente.getCodigo();
                    }
                    if(cliente.getNombre() != null){
                        nombre = cliente.getNombre();
                    }
                    if(cliente.getApellido() != null){
                        apellido = cliente.getApellido();
                    }
                    if(cliente.getIdentificacion()!= null){
                        cedCli = cliente.getIdentificacion();
                    }
                    if(cliente.getDireccion()!= null){
                        direccion = cliente.getDireccion();
                    }
                    if(cliente.getTelefono()!= null){
                        telefono = cliente.getTelefono();
                    }
                    if(cliente.getEmail()!= null){
                        email = cliente.getEmail();
                    }
                   out.print(codCli+"|"+cedCli+"|"+nombre+"|"+apellido+"|"+direccion+"|"+telefono+"|"+email);
                }
                else
                {
                    out.print("1|0000000000|Consu|Final|Tumbaco|2593954|frigo@gmail.com");
                }
            }
            else{
                out.print("1|0000000000|Consu|Final|Tumbaco|2593954|frigo@gmail.com");
            }
        }
        //B es para Decripcion del Producto     
        if(cod.equals("B")){
            String prod = codigo.substring(2, codigo.length());
            if (!prod.isEmpty() || !prod.equals("null")){
                producto = productoDao.buscar(prod);
                if(producto != null){
                    Integer codPro = 0;
                    String descripcion = "NO EXISTE";
                    Double precio = 0.00;
                    if (producto.getCodigo()>0){
                        codPro = producto.getCodigo();
                    }
                    if (producto.getDescripcion()!= null){
                        descripcion = producto.getDescripcion();
                    }
                    if (producto.getPrecio()!= null){
                        precio = producto.getPrecio();
                    }
                    out.print(codPro+"|"+descripcion+"|"+precio);
                }
                else
                {
                    out.print("0|NO EXISTE|0.00");
                }
            }
            else{
                out.print("0|NO EXISTE|0.00");
            }
        }
        //C validacion de apertura de Caja     
        if(cod.equals("C")){
            String caja1 = codigo.substring(2, codigo.length());            
             aperturaCaja.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             aperturaCaja.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
             aperturaCaja.setCaja(Integer.parseInt(caja1));   
             validaAperturaCaja = aperturaCajaDAO.validateOpen(aperturaCaja);
            if (validaAperturaCaja!= null){
                String estado = "X";
                Double saldo_caja = 0.0;
                if(validaAperturaCaja.getEstado()!=null){
                 estado = validaAperturaCaja.getEstado();
                 saldo_caja = validaAperturaCaja.getSaldoCaja();
                }
                out.print("1|"+estado+"|"+saldo_caja);                
            }
            else{
                out.print("0|X");
            }
        }
        //D Obtiene Descripcion     
        if(cod.equals("D")){
            String datos = codigo.substring(2, codigo.length()); 
            if (!datos.equals("")){
             String[] parametros = datos.split("\\|");             
             tabla.setTabla(parametros[0]);
             tabla.setCampo(parametros[1]);
             tabla.setCampoCodigo(parametros[2]);
             tabla.setCodigo(Integer.parseInt(parametros[3]));               
             String descripcion = comunesDAO.getDescripcion(tabla);                
             if (descripcion!= null){                                
                out.print(descripcion);                
             }
             else{
                out.print("X");
             }
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
