/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

import DAO.Ad_UsuarioDAO;
import DAO.Ad_UsuarioRolDAO;
import DAO.Cl_ClienteDAO;
import DAO.Cl_ProductoDAO;
import DAO.Tr_TransaccionMonetariaDAO;
import DAO.Tr_AperturaCajaDAO;
import DAO.Tr_FacturaDAO;
import DAO.Ad_ComunesDAO;
import DAO.Ad_CajaDAO;
import Model.Ad_Usuario;
import Model.Ad_UsuarioRol;
import Model.Cl_Cliente;
import Model.Cl_Producto;
import Model.Tr_TransaccionMonetaria;
import Model.Tr_AperturaCaja;
import Model.Tr_Factura;
import Model.Tr_DetalleFactura;
import Model.Ad_Caja;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author gcueva
 */

public class Controlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //Inicio
    String principal = "/Principal.jsp";    
    String index = "/index.jsp";    
    String seleccionarRol = "views/seleccionarRol.jsp";
    String selectCaja = "views/selectCaja.jsp";
    //Usuarios    
    String admUsuarios = "views/admUsuarios.jsp";
    String listarUsuarios = "views/listarUsuarios.jsp";
    String addUsuario = "views/addUsuario.jsp";
    String editUsuario = "views/editUsuario.jsp";   
    String listarUsuarioRol = "views/listarUsuarioRol.jsp";
    String addUsuarioRol = "views/addUsuarioRol.jsp";
    //Clientes
    String listarClientes = "views/listarClientes.jsp";
    String addCliente = "views/addCliente.jsp";
    String editCliente = "views/editCliente.jsp";
    //Productos
    String listarProductos = "views/listarProductos.jsp";
    String addProducto = "views/addProducto.jsp";
    String editProducto = "views/editProducto.jsp";
    //Transacciones
    String addTransaccionMonetaria = "views/addTransaccionMonetaria.jsp";
    String addFactura = "views/addFactura.jsp";
    //Cajas
    String adminCajas = "views/admCajas.jsp"; 
    String listarCajas = "views/listarCajas.jsp";
    String addCaja = "views/addCaja.jsp";
    String editCaja = "views/editCaja.jsp"; 
    String aperturarCaja = "views/abrirCaja.jsp"; 
    String cierreCaja = "views/cierreCaja.jsp";
    //Reportes
    String adminReportes = "views/admReportes.jsp"; 
    String repCajas = "views/repCajas.jsp"; 
    String repVentas = "views/repVentas.jsp"; 
    //Clases
    Ad_Usuario usuario = new Ad_Usuario();
    Ad_UsuarioDAO usuarioDao = new Ad_UsuarioDAO();    
    Ad_UsuarioRol usuarioRol = new Ad_UsuarioRol();
    Ad_UsuarioRolDAO usuarioRolDao = new Ad_UsuarioRolDAO();    
    Cl_Cliente cliente = new Cl_Cliente();
    Cl_ClienteDAO clienteDao = new Cl_ClienteDAO();    
    Cl_Producto producto = new Cl_Producto();
    Cl_ProductoDAO productoDao = new Cl_ProductoDAO();    
    Tr_TransaccionMonetaria transaccionMonetaria = new Tr_TransaccionMonetaria();
    Tr_TransaccionMonetariaDAO transaccionMonetariaDAO = new Tr_TransaccionMonetariaDAO();    
    Tr_AperturaCaja aperturaCaja = new Tr_AperturaCaja();
    Tr_AperturaCaja validaAperturaCaja = new Tr_AperturaCaja();
    Tr_AperturaCajaDAO aperturaCajaDAO = new Tr_AperturaCajaDAO();    
    Tr_Factura factura = new Tr_Factura();
    Tr_FacturaDAO facturaDAO = new Tr_FacturaDAO();    
    Ad_ComunesDAO comunes = new Ad_ComunesDAO();    
    Ad_Caja caja = new Ad_Caja();
    Ad_CajaDAO cajaDao = new Ad_CajaDAO();
    //Variables
    int codUsuario;
    
    //Metodos
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String acceso = "";
        String action = request.getParameter("accion");
        if(action.equals("Ingresar")){
            String login = request.getParameter("txtUsuario");
            String password = request.getParameter("txtPassword");
            usuario.setLogin(login);
            usuario.setPassword(password);
            try{
                codUsuario = usuarioDao.validar(usuario);
                if(codUsuario > 0){
                    request.getSession().setAttribute("login", login);
                    request.getSession().setAttribute("codLogin", codUsuario);
                    request.getSession().setAttribute("msg","");
                    acceso = seleccionarRol;
                }else{
                    request.getSession().setAttribute("msg","Error de autenticación");
                    acceso = index;
                }
            }catch(Exception e){
                System.out.println("Error al validar usuario: " + e.getMessage());
                acceso = index;                
            }
            
        }else if(action.equals("Entrar")){
            Integer usuarioR = Integer.parseInt(request.getParameter("txtUsuario"));
            Integer oficinaR = Integer.parseInt(request.getParameter("txtOficina"));
            Integer rolR = Integer.parseInt(request.getParameter("txtRol"));            
            usuarioRol.setUsuario(usuarioR);
            usuarioRol.setOficina(oficinaR);
            usuarioRol.setRol(rolR);            
            codUsuario = usuarioRolDao.validar(usuarioRol);
            if(codUsuario > 0){
                request.getSession().setAttribute("oficina", oficinaR);
                request.getSession().setAttribute("rol", rolR);
                request.getSession().setAttribute("msg","");
                List listarCajas = usuarioRolDao.listarCajas(usuarioRol);
                if(listarCajas.size()>0)
                {
                    acceso = selectCaja;
                }
                else
                {  
                    request.getSession().setAttribute("codCaja", "");
                    acceso = principal;
                }
                
            }else{
                request.getSession().setAttribute("msg","Rol no permitido");
                acceso = seleccionarRol;
            }
        }else if(action.equalsIgnoreCase("Salir")){            
             acceso = index; 
        }else if(action.equalsIgnoreCase("Continuar")){  
             request.getSession().setAttribute("codCaja", Integer.parseInt(request.getParameter("txtCaja")));
             acceso = principal; 
        }else if(action.equalsIgnoreCase("Principal")){            
             acceso = principal; 
        }else if(action.equalsIgnoreCase("listarUsuarios")){
            acceso = listarUsuarios;
        }else if (action.equalsIgnoreCase("addUsuario")) {
             acceso = addUsuario;
        }else if (action.equalsIgnoreCase("AgregarUsuario")) {            
            usuario.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            usuario.setNombre(request.getParameter("txtNombre"));
            usuario.setLogin(request.getParameter("txtLogin"));
            usuario.setPassword(request.getParameter("txtPassword"));
            usuarioDao.add(usuario);
            acceso = listarUsuarios;            
        }else if(action.equalsIgnoreCase("editarUsuario")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editUsuario; 
        }else if(action.equalsIgnoreCase("ActualizarUsuario")){
            usuario.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            usuario.setNombre(request.getParameter("txtNombre"));
            usuario.setLogin(request.getParameter("txtLogin"));
            usuario.setPassword(request.getParameter("txtPassword"));
            usuarioDao.edit(usuario);
            acceso = listarUsuarios;     
        }else if(action.equalsIgnoreCase("eliminarUsuario")){
            usuario.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            usuarioDao.eliminar(usuario.getCodigo());
            acceso = listarUsuarios;     
        }else if(action.equalsIgnoreCase("listarUsuarioRol")){
            acceso = listarUsuarioRol;
        }else if(action.equalsIgnoreCase("addUsuarioRol")){
            acceso = addUsuarioRol;
        }else if (action.equalsIgnoreCase("AgregarUsuarioRol")) {            
            usuarioRol.setOficina(Integer.parseInt(request.getParameter("txtOficina")));
            usuarioRol.setUsuario(Integer.parseInt(request.getParameter("txtUsuario")));
            usuarioRol.setRol(Integer.parseInt(request.getParameter("txtRol")));
            usuarioRol.setCaja(Integer.parseInt(request.getParameter("txtCaja")));
            usuarioRolDao.add(usuarioRol);
            acceso = listarUsuarioRol;            
        }else if(action.equalsIgnoreCase("listarClientes")){
            acceso = listarClientes;
        }else if (action.equalsIgnoreCase("addCliente")) {
            acceso = addCliente;
        }else if (action.equalsIgnoreCase("AgregarCliente")) {            
            cliente.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            cliente.setIdentificacion(request.getParameter("txtIdentificacion"));
            cliente.setNombre(request.getParameter("txtNombre"));
            cliente.setApellido(request.getParameter("txtApellido"));
            cliente.setDireccion(request.getParameter("txtDireccion"));
            cliente.setTelefono(request.getParameter("txtTelefono"));
            cliente.setEmail(request.getParameter("txtEmail"));
            clienteDao.add(cliente);
            acceso = listarClientes;            
        }else if(action.equalsIgnoreCase("editarCliente")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editCliente; 
        }else if(action.equalsIgnoreCase("ActualizarCliente")){
            cliente.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            cliente.setIdentificacion(request.getParameter("txtIdentificacion"));
            cliente.setNombre(request.getParameter("txtNombre"));
            cliente.setApellido(request.getParameter("txtApellido"));
            cliente.setDireccion(request.getParameter("txtDireccion"));
            cliente.setTelefono(request.getParameter("txtTelefono"));
            cliente.setEmail(request.getParameter("txtEmail"));
            clienteDao.edit(cliente);
            acceso = listarClientes;     
        }else if(action.equalsIgnoreCase("eliminarCliente")){
            cliente.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            clienteDao.eliminar(cliente.getCodigo());
            acceso = listarClientes;     
        }else if(action.equalsIgnoreCase("listarProductos")){
            acceso = listarProductos;
        }else if (action.equalsIgnoreCase("addProducto")) {
            acceso = addProducto;
        }else if (action.equalsIgnoreCase("AgregarProducto")) {            
            producto.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            producto.setProducto(request.getParameter("txtProducto"));
            producto.setDescripcion(request.getParameter("txtDescripcion"));
            producto.setPrecio(Double.parseDouble(request.getParameter("txtPrecio")));
            producto.setCantidad(Integer.parseInt(request.getParameter("txtCantidad")));            
            productoDao.add(producto);
            acceso = listarProductos;            
        }else if(action.equalsIgnoreCase("editarProducto")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editProducto; 
        }else if(action.equalsIgnoreCase("ActualizarProducto")){
            producto.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            producto.setProducto(request.getParameter("txtProducto"));
            producto.setDescripcion(request.getParameter("txtDescripcion"));
            producto.setPrecio(Double.parseDouble(request.getParameter("txtPrecio")));
            producto.setCantidad(Integer.parseInt(request.getParameter("txtCantidad")));           
            productoDao.edit(producto);
            acceso = listarProductos;     
        }else if(action.equalsIgnoreCase("eliminarProducto")){
            producto.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            productoDao.eliminar(producto.getCodigo());
            acceso = listarProductos;     
        }else if (action.equalsIgnoreCase("addTransaccionMonetaria")) {
             acceso = addTransaccionMonetaria;
        }else if (action.equalsIgnoreCase("AgregarTransaccion")) {             
             transaccionMonetaria.setTransaccion(Integer.parseInt(request.getParameter("txtTransaccion")));
             transaccionMonetaria.setCausa(Integer.parseInt(request.getParameter("txtCausa")));
             transaccionMonetaria.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             transaccionMonetaria.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
             transaccionMonetaria.setCaja(Integer.parseInt(request.getSession().getAttribute("codCaja").toString()));
             transaccionMonetaria.setValor(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             if (request.getParameter("txtCheque") != null && !request.getParameter("txtCheque").equals("")){
                 transaccionMonetaria.setCheque(Double.parseDouble(request.getParameter("txtCheque").replaceAll(",", "")));
                 transaccionMonetaria.setNumeroCheque(Integer.parseInt(request.getParameter("txtNumeroCheque")));
             } 
             else{
                 transaccionMonetaria.setCheque(0.0);
                 transaccionMonetaria.setNumeroCheque(0);
             }             
             transaccionMonetaria.setDescripcion(request.getParameter("txtDescripcion"));
             transaccionMonetariaDAO.add(transaccionMonetaria);
             acceso = principal; 
        }else if (action.equalsIgnoreCase("AgregarFactura")) {     
              try{
             //Transaccion Monetaria
             transaccionMonetaria.setTransaccion(100);//Transaccion Ingresos
             transaccionMonetaria.setCausa(1);//Causa Ventas
             transaccionMonetaria.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             transaccionMonetaria.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
             transaccionMonetaria.setCaja(Integer.parseInt(request.getSession().getAttribute("codCaja").toString()));
             transaccionMonetaria.setValor(Double.parseDouble(request.getParameter("txtTotal").replaceAll(",", "")));
             transaccionMonetaria.setCheque(0.0);
             transaccionMonetaria.setNumeroCheque(0);             
             factura.setTransaccionMonetaria(transaccionMonetaria);
             //Datos Factura
             factura.setCodCliente(Integer.parseInt(request.getParameter("txtCliente")));
             factura.setSubtotal(Double.parseDouble(request.getParameter("txtSubtotal").replaceAll(",", "")));
             factura.setIva(Double.parseDouble(request.getParameter("txtIva").replaceAll(",", "")));
             factura.setTotal(Double.parseDouble(request.getParameter("txtTotal").replaceAll(",", ""))); 
             //DatosCliente
             cliente.setCodigo(Integer.parseInt(request.getParameter("txtCliente")));
             cliente.setIdentificacion(request.getParameter("txtIdentificacion"));
             cliente.setNombre(request.getParameter("txtNombreCliente"));
             cliente.setApellido(request.getParameter("txtApellidoCliente"));
             cliente.setDireccion(request.getParameter("txtDireccion"));
             cliente.setTelefono(request.getParameter("txtTelefono"));
             cliente.setEmail(request.getParameter("txtEmail"));
             //Fin DatosCliente
             ArrayList<Tr_DetalleFactura> detalleFactura = new ArrayList();             
             String[] codProd = new String[5];
             String[] cantidad = new String[5];
             String[] precio = new String[5];                            
             if(request.getParameterValues("codProd")!=null)
                 codProd = request.getParameterValues("codProd");             
             if(request.getParameterValues("cantidad")!=null)
                 cantidad = request.getParameterValues("cantidad");             
             if(request.getParameterValues("precio")!=null)
                 precio = request.getParameterValues("precio");                          
             for(int i=0; i< 5;i++){
                 Tr_DetalleFactura dF = new Tr_DetalleFactura();                         
                 dF.setSecuencial(i+1);
                if(codProd[i]!=null && !codProd[i].equals(""))
                 dF.setCodigo(Integer.parseInt(codProd[i]));
                if(cantidad[i]!=null && !cantidad[i].equals(""))
                 dF.setCantidad(Integer.parseInt(cantidad[i]));
                if(precio[i]!=null && !precio[i].equals(""))
                 dF.setValor(Double.parseDouble(precio[i]));
                dF.setEstado("A");
                detalleFactura.add(dF);
             }
             if(cliente.getCodigo() == 0){
                 clienteDao.add(cliente);
                 factura.setCodCliente(cliente.getCodigo());
             }             
                factura.setDetalleFactura(detalleFactura);            
                facturaDAO.add(factura);
                acceso = addFactura; 
             }catch(Exception e){
                acceso = addFactura; 
                request.getSession().setAttribute("mensajeError", "Error al Generar la Factura");
                System.out.println("Error al agregar la Factura: " + e.getMessage());
            }                         
        }else if (action.equalsIgnoreCase("addFactura")) {
             acceso = addFactura;
        }else if(action.equalsIgnoreCase("listarCajas")){
            acceso = listarCajas;
        }else if (action.equalsIgnoreCase("addCaja")) {
             acceso = addCaja;
        }else if (action.equalsIgnoreCase("AgregarCaja")) {            
            caja.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            caja.setNombre(request.getParameter("txtNombre"));
            caja.setOficina(Integer.parseInt(request.getParameter("txtOficina")));            
            cajaDao.add(caja);
            acceso = listarCajas;            
        }else if(action.equalsIgnoreCase("editarCaja")){
            request.setAttribute("codigo", request.getParameter("codigo"));
            acceso = editCaja; 
        }else if(action.equalsIgnoreCase("ActualizarCaja")){
            caja.setCodigo(Integer.parseInt(request.getParameter("txtCodigo")));
            caja.setNombre(request.getParameter("txtNombre"));
            caja.setOficina(Integer.parseInt(request.getParameter("txtOficina")));            
            cajaDao.edit(caja);
            acceso = listarCajas;     
        }else if(action.equalsIgnoreCase("eliminarCaja")){
            caja.setCodigo(Integer.parseInt(request.getParameter("codigo")));          
            cajaDao.eliminar(caja.getCodigo());
            acceso = listarCajas;     
        }else if(action.equalsIgnoreCase("adminCajas")){            
            acceso = adminCajas;     
        }else if(action.equalsIgnoreCase("aperturarCaja")){            
            acceso = aperturarCaja;     
        }else if(action.equalsIgnoreCase("cierreCaja")){            
            acceso = cierreCaja;     
        }else if (action.equalsIgnoreCase("AbrirCaja")) {             
             aperturaCaja.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             aperturaCaja.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));             
             aperturaCaja.setCaja(Integer.parseInt(request.getParameter("txtCaja")));             
             aperturaCaja.setValorApertura(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             aperturaCaja.setSaldoCaja(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             aperturaCajaDAO.add(aperturaCaja);
             request.getSession().setAttribute("codCaja", aperturaCaja.getCaja());
             acceso = aperturarCaja; 
        }else if (action.equalsIgnoreCase("CerrarCaja")) {             
             aperturaCaja.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             aperturaCaja.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));             
             aperturaCaja.setCaja(Integer.parseInt(request.getParameter("txtCaja")));             
             aperturaCaja.setValorCierre(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             aperturaCaja.setSaldoCaja(Double.parseDouble(request.getParameter("txtValor").replaceAll(",", "")));
             aperturaCajaDAO.close(aperturaCaja);
             request.getSession().setAttribute("codCaja", aperturaCaja.getCaja());
             acceso = cierreCaja; 
        }else if(action.equalsIgnoreCase("adminReportes")){            
            acceso = adminReportes;     
        }else if(action.equalsIgnoreCase("repCajas")){            
            acceso = repCajas;     
        }else if(action.equalsIgnoreCase("repVentas")){            
            acceso = repVentas;     
        }else if(action.equalsIgnoreCase("admUsuarios")){            
            acceso = admUsuarios;     
        }
                
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();  
        String codigo = request.getParameter("codigo");   
        String cod = codigo.substring(0, 1);
        //A es para Busqueda De Cliente
        if(cod.equals("A")){
            String cedula = codigo.substring(2, codigo.length());
            if (!cedula.isEmpty() || !cedula.equals("null")){
                cliente = clienteDao.buscar(cedula);
                if(cliente!=null){
                    Integer codCli = 0;
                    String nombre = "";
                    String apellido = "";
                    String cedCli = "";
                    String direccion = "";
                    String telefono = "";
                    String email = "";
                    
                    if(cliente.getCodigo() > 0){
                        codCli = cliente.getCodigo();
                    }
                    if(cliente.getNombre() != null){
                        nombre = cliente.getNombre();
                    }
                    if(cliente.getApellido() != null){
                        apellido = cliente.getApellido();
                    }
                    if(cliente.getIdentificacion()!= null){
                        cedCli = cliente.getIdentificacion();
                    }
                    if(cliente.getDireccion()!= null){
                        direccion = cliente.getDireccion();
                    }
                    if(cliente.getTelefono()!= null){
                        telefono = cliente.getTelefono();
                    }
                    if(cliente.getEmail()!= null){
                        email = cliente.getEmail();
                    }
                   out.print(codCli+"|"+cedCli+"|"+nombre+"|"+apellido+"|"+direccion+"|"+telefono+"|"+email);
                }
                else
                {
                    out.print("1|0000000000|Consu|Final|Tumbaco|2593954|frigo@gmail.com");
                }
            }
            else{
                out.print("1|0000000000|Consu|Final|Tumbaco|2593954|frigo@gmail.com");
            }
        }
        //B es para Decripcion del Producto     
        if(cod.equals("B")){
            String prod = codigo.substring(2, codigo.length());
            if (!prod.isEmpty() || !prod.equals("null")){
                producto = productoDao.buscar(prod);
                if(producto != null){
                    Integer codPro = 0;
                    String descripcion = "NO EXISTE";
                    Double precio = 0.00;
                    if (producto.getCodigo()>0){
                        codPro = producto.getCodigo();
                    }
                    if (producto.getDescripcion()!= null){
                        descripcion = producto.getDescripcion();
                    }
                    if (producto.getPrecio()!= null){
                        precio = producto.getPrecio();
                    }
                    out.print(codPro+"|"+descripcion+"|"+precio);
                }
                else
                {
                    out.print("0|NO EXISTE|0.00");
                }
            }
            else{
                out.print("0|NO EXISTE|0.00");
            }
        }
        //C validacion de apertura de Caja     
        if(cod.equals("C")){
            String caja1 = codigo.substring(2, codigo.length());            
             aperturaCaja.setOficina(Integer.parseInt(request.getSession().getAttribute("oficina").toString()));
             aperturaCaja.setUsuario(Integer.parseInt(request.getSession().getAttribute("codLogin").toString()));
             aperturaCaja.setCaja(Integer.parseInt(caja1));   
             validaAperturaCaja = aperturaCajaDAO.validateOpen(aperturaCaja);
            if (validaAperturaCaja!= null){
                String estado = "X";
                if(validaAperturaCaja.getEstado()!=null){
                 estado = validaAperturaCaja.getEstado();
                }
                out.print("1|"+estado);                
            }
            else{
                out.print("0|X");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
