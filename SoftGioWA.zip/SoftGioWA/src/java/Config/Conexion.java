/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Config;

import java.sql.*;

/**
 *
 * @author gcueva
 */
public class Conexion {
    /*Connection conectar = null;
    public Connection conexion(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection("jdbc:mysql://localhost:3306/softgio?user=root&password=root");
        }               
        catch(Exception e){
            System.err.println("Error"+e);
        }
        return conectar;
    }*/
    
    //BIEN
     Connection con;
    public Conexion(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            //Local
            //con = DriverManager.getConnection("jdbc:mysql://localhost:3306/softgio?autoReconnect=true&useSSL=false", "root", "root");
            //Cloud
            con = DriverManager.getConnection("jdbc:mysql://softgio.cqfv6hkzidfs.us-east-1.rds.amazonaws.com:3306/softgio?autoReconnect=true&useSSL=false", "admin", "softgio1985");
        }               
        catch(Exception e){
            System.err.println("Error"+e);
        }
    }
    public Connection getConnection(){
    return con;
    }
    /*Connection con;
    public Connection getConnection(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/softgio", "root", "root");
            
        } catch (Exception e) {
        }
        return con;
    }*/
    
}
