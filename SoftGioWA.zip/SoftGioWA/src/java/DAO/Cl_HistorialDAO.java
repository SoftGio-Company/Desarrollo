/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.HistorialCRUD;
import Model.Ad_Tabla;
import Model.Cl_Historial;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_HistorialDAO implements HistorialCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Historial h = new Cl_Historial();
    
    @Override
    public List listar(String codigo) {
        //Metetodo que consulta la lista de Usuarios

        ArrayList<Cl_Historial> list = new ArrayList<>();
        String sql = "select * from cl_historial where hi_cliente ="+codigo+"  and hi_codigo > 0  order by hi_codigo asc limit 20";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Cl_Historial his = new Cl_Historial();
                his.setCodigo(rs.getInt("hi_codigo"));
                his.setFecha(rs.getDate("hi_fecha"));
                his.setOficina(rs.getInt("hi_oficina"));                
                his.setCliente(rs.getInt("hi_cliente"));
                his.setMedico(rs.getInt("hi_medico"));
                his.setHora(rs.getTime("hi_hora"));  
                his.setTipo(rs.getString("hi_tipo"));  
                his.setDescripcion(rs.getString("hi_descripcion"));  
                
                list.add(his);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Cl_Historial list(int codigo) {
        //Metodo que consulta un Usuario   
        Integer cod = new Integer(0);
        h = new Cl_Historial();        
        if(cod == codigo){            
            h.setCodigo(0);
            h.setFecha(null);
            h.setOficina(0);
            h.setCliente(0);
            h.setUsuario(0);
            h.setMedico(0);
            h.setHora(null);
            h.setTipo("");
            h.setDescripcion("");
        }
        else{
        String sql = "select * from cl_historial where hi_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                
                h.setCodigo(rs.getInt("hi_codigo"));
                h.setFecha(rs.getDate("hi_fecha"));
                h.setOficina(rs.getInt("hi_oficina"));
                h.setUsuario(rs.getInt("hi_usuario"));
                h.setCliente(rs.getInt("hi_cliente"));
                h.setMedico(rs.getInt("hi_medico"));
                h.setHora(rs.getTime("hi_hora"));
                h.setTipo(rs.getString("hi_tipo"));
                h.setDescripcion(rs.getString("hi_descripcion"));                
            }
        } catch (Exception e) {
        }
        }
        return h;
    }
    @Override
    public Cl_Historial buscar(String cedula) {       
        String sql = "Select * from cl_historial where hi_cliente = (select cl_codigo from cl_cliente where cl_identificacion ="+cedula+")";
        h = new Cl_Historial();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();            
           while(rs.next()){
                h.setCodigo(rs.getInt("hi_codigo"));
                h.setFecha(rs.getDate("hi_identificacion"));
                h.setOficina(rs.getInt("hi_oficina"));
                h.setUsuario(rs.getInt("hi_usuario"));
                h.setCliente(rs.getInt("hi_cliente"));
                h.setMedico(rs.getInt("hi_medico"));
                h.setHora(rs.getTime("hi_hora"));
                h.setTipo(rs.getString("hi_tipo"));
                h.setDescripcion(rs.getString("hi_descripcion"));           
            }
            
        } catch (Exception e) {
            
        }
        return h;
    }

    @Override
    public boolean add(Cl_Historial his) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();        
        his.setFecha(fecha);        
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_historial");
        tabla.setCampo("hi_codigo");
        his.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_historial(hi_codigo,hi_fecha,hi_oficina,hi_usuario,hi_cliente,hi_medico,hi_hora,hi_tipo,hi_descripcion) values ('"+
                his.getCodigo()+"',NOW(),'"+  
                his.getOficina()+"','"+
                his.getUsuario()+"','"+
                his.getCliente()+"','"+
                his.getMedico()+"',CURRENT_TIME(),'"+ 
                his.getTipo()+"','"+                
                his.getDescripcion()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Historial his) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        his.setFecha(fecha);        
        String sql = "update cl_historial set cl_tipo ='"+his.getTipo()+"', "
                + "cl_descripcion='"+his.getDescripcion()+"' where hi_codigo ="+his.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_historial where hi_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
