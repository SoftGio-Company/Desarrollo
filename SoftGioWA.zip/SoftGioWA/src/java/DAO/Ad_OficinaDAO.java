/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.OficinaCRUD;
import Model.Ad_Oficina;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Ad_OficinaDAO implements OficinaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Ad_Oficina o = new Ad_Oficina();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Oficina> list = new ArrayList<>();
        String sql = "select * from ad_oficina";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Oficina ofi = new Ad_Oficina();
                ofi.setCodigo(rs.getInt("of_codigo"));                
                ofi.setDescripcion(rs.getString("of_descripcion"));                                
                ofi.setFecha(rs.getDate("of_fecha"));
                ofi.setEstado(rs.getString("of_estado"));
                list.add(ofi);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List listarCatalogo() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Oficina> list = new ArrayList<>();
        String sql = "select * from ad_oficina";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Oficina ofi = new Ad_Oficina();
                ofi.setCodigo(rs.getInt("of_codigo"));                
                ofi.setDescripcion(rs.getString("of_descripcion"));                
                list.add(ofi);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Ad_Oficina list(int codigo) {
        //Metodo que consulta un Ad_Transaccion       
        String sql = "select * from ad_oficina where of_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                o.setCodigo(rs.getInt("of_codigo"));                
                o.setDescripcion(rs.getString("of_descripcion"));                               
                o.setFecha(rs.getDate("of_fecha"));
                o.setEstado(rs.getString("of_estado"));
                
            }
        } catch (Exception e) {
        }
        return o;
    }

    @Override
    public boolean add(Ad_Oficina ofi) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();
        ofi.setFecha(fecha);
        ofi.setEstado("V");
        String sql = "insert into ad_oficina(of_codigo,of_descripcion,of_fecha,of_estado) values ('"+
                ofi.getCodigo()+"','"+                
                ofi.getDescripcion()+"',NOW(),'"+                
                ofi.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_Oficina ofi) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        ofi.setFecha(fecha);
        ofi.setEstado("V");
        String sql = "update ad_oficina set of_descripcion='"+ofi.getDescripcion()+"',"                              
                + "of_estado='"+ofi.getEstado()+"' where of_codigo ="+ofi.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from ad_oficina where of_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
