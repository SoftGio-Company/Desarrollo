/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.UsuarioRolCRUD;
import Model.Ad_UsuarioRol;
import Model.Tr_AperturaCaja;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Ad_UsuarioRolDAO implements UsuarioRolCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;
    Ad_UsuarioRol ur = new Ad_UsuarioRol();
    
    
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Usuarios
        ArrayList<Ad_UsuarioRol> list = new ArrayList<>();
        String sql = "select * from ad_usuario_rol";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_UsuarioRol usr = new Ad_UsuarioRol();
                usr.setOficina(rs.getInt("ur_oficina"));
                usr.setUsuario(rs.getInt("ur_usuario"));
                usr.setRol(rs.getInt("ur_rol"));
                usr.setCaja(rs.getInt("ur_caja"));
                usr.setFecha(rs.getDate("ur_fecha"));
                usr.setEstado(rs.getString("ur_estado"));
                list.add(usr);
            }
        } catch (Exception e) {
        }
        return list;
    }   

    @Override
    public Ad_UsuarioRol list(int usuario) {
        //Metodo que consulta un Usuario        
        String sql = "select * from ad_usuario_rol where ur_usuario ="+usuario;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                ur.setOficina(rs.getInt("ur_oficina"));
                ur.setUsuario(rs.getInt("ur_usuario"));
                ur.setRol(rs.getInt("ur_rol"));
                ur.setCaja(rs.getInt("ur_caja"));
                ur.setFecha(rs.getDate("ur_fecha"));
                ur.setEstado(rs.getString("ur_estado"));
                
            }
        } catch (Exception e) {
        }
        return ur;
    }

    @Override
    public boolean add(Ad_UsuarioRol usr) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        usr.setFecha(fecha);
        usr.setEstado("V");
        
  
        String sql = "insert into ad_usuario_rol(ur_oficina,ur_usuario,ur_rol,ur_caja,ur_fecha,ur_estado) values ('"+
                usr.getOficina()+"','"+
                usr.getUsuario()+"','"+
                usr.getRol()+"','"+
                usr.getCaja()+"',NOW(),'"+                
                usr.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_UsuarioRol usr) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        usr.setFecha(fecha);
        usr.setEstado("V");
        String sql = "update ad_usuario_rol set ur_oficina ='"+usr.getOficina()+"', "
                + "ur_usuario='"+usr.getUsuario()+"',"
                + "ur_rol='"+usr.getRol()+"',"
                + "ur_caja='"+usr.getCaja()+"',"
                + "ur_estado='"+usr.getEstado()+"' where ur_usuario ="+usr.getUsuario();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int usuario) {
        String sql = "delete  from ad_usuario_rol where ur_usuario ="+usuario;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    @Override
    public int validar(Ad_UsuarioRol usr) {
        String sql = "Select * from ad_usuario_rol where ur_usuario=? and ur_oficina =? and ur_rol=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, usr.getUsuario());
            ps.setInt(2, usr.getOficina());
            ps.setInt(3, usr.getRol());            
            rs = ps.executeQuery();
            r = 0;
            while(rs.next()){
                r = r + 1;
                usr.setUsuario(rs.getInt("ur_usuario"));
            }
            if(r>=1){
                return usr.getUsuario();
            }else{
                return 0;
            }
            
        } catch (Exception e) {
            return 0;
        }
        
    }       
    
    @Override
    public List listarCajas(Ad_UsuarioRol usr) {
        //Metetodo que consulta la lista de Usuarios
        ArrayList<Tr_AperturaCaja> listCajas = new ArrayList<>();
        String sql = "Select * from tr_apertura_caja where ac_usuario=? and ac_oficina =? and ac_estado='A'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, usr.getUsuario());
            ps.setInt(2, usr.getOficina());
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_AperturaCaja ac = new Tr_AperturaCaja();
                ac.setOficina(rs.getInt("ac_oficina"));
                ac.setUsuario(rs.getInt("ac_usuario"));                
                ac.setCaja(rs.getInt("ac_caja"));
                ac.setFecha(rs.getDate("ac_fecha"));
                ac.setEstado(rs.getString("ac_estado"));
                listCajas.add(ac);
            }
        } catch (Exception e) {
        }
        return listCajas;
    }   
    
    
}
