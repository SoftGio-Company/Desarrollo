/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.ProveedorCRUD;
import Model.Ad_Tabla;
import Model.Cl_Proveedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_ProveedorDAO implements ProveedorCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Proveedor prov = new Cl_Proveedor();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Usuarios
        ArrayList<Cl_Proveedor> list = new ArrayList<>();
        String sql = "select * from cl_proveedor";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Cl_Proveedor pro = new Cl_Proveedor();
                pro.setCodigo(rs.getInt("pr_codigo"));
                pro.setIdentificacion(rs.getString("pr_identificacion"));
                pro.setNombre(rs.getString("pr_nombre"));                
                pro.setDireccion(rs.getString("pr_direccion"));
                pro.setTelefono(rs.getString("pr_telefono"));
                pro.setEmail(rs.getString("pr_email"));
                pro.setFecha(rs.getDate("pr_fecha"));
                pro.setEstado(rs.getString("pr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Cl_Proveedor list(int codigo) {
        //Metodo que consulta un Usuario     
        Integer cod = new Integer(0);
        prov = new Cl_Proveedor();        
        if(cod == codigo){            
            prov.setCodigo(0);
            prov.setIdentificacion("");
            prov.setNombre("");            
            prov.setDireccion("");
            prov.setTelefono("");
            prov.setEmail("");
        }
        else{
        String sql = "select * from cl_proveedor where pr_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                prov.setCodigo(rs.getInt("pr_codigo"));
                prov.setIdentificacion(rs.getString("pr_identificacion"));
                prov.setNombre(rs.getString("pr_nombre"));                
                prov.setDireccion(rs.getString("pr_direccion"));
                prov.setTelefono(rs.getString("pr_telefono"));
                prov.setEmail(rs.getString("pr_email"));
                prov.setFecha(rs.getDate("pr_fecha"));
                prov.setEstado(rs.getString("pr_estado"));
                
            }
        } catch (Exception e) {
        }
        }
        return prov;
    }
    @Override
    public Cl_Proveedor buscar(String cedula) {       
        String sql = "Select pr_codigo,pr_identificacion,pr_nombre,pr_direccion,pr_telefono,pr_email from cl_proveedor where pr_identificacion ="+cedula;
        prov = new Cl_Proveedor();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();
            prov.setIdentificacion(cedula);
           while(rs.next()){
            prov.setCodigo(rs.getInt("pr_codigo"));
            prov.setIdentificacion(rs.getString("pr_identificacion"));
            prov.setNombre(rs.getString("pr_nombre"));            
            prov.setDireccion(rs.getString("pr_direccion"));
            prov.setTelefono(rs.getString("pr_telefono"));
            prov.setEmail(rs.getString("pr_email"));           
            }
            
        } catch (Exception e) {
            
        }
        return prov;
    }

    @Override
    public boolean add(Cl_Proveedor pro) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_proveedor");
        tabla.setCampo("pr_codigo");
        pro.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_proveedor(pr_codigo,pr_identificacion,pr_nombre,pr_direccion,pr_telefono,pr_email,pr_fecha,pr_estado) values ('"+
                pro.getCodigo()+"','"+
                pro.getIdentificacion()+"','"+
                pro.getNombre()+"','"+                
                pro.getDireccion()+"','"+
                pro.getTelefono()+"','"+ 
                pro.getEmail()+"',NOW(),'"+ 
                pro.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Proveedor pro) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        String sql = "update cl_proveedor set pr_identificacion ='"+pro.getIdentificacion()+"', "
                + "pr_nombre='"+pro.getNombre()+"',"                
                + "pr_direccion='"+pro.getDireccion()+"',"
                + "pr_telefono='"+pro.getTelefono()+"',"
                + "pr_email='"+pro.getEmail()+"',"
                + "pr_estado='"+pro.getEstado()+"' where pr_codigo ="+pro.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_proveedor where pr_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
