/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.DetalleFacturaCRUD;
import Model.Tr_DetalleFactura;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Tr_DetalleFacturaDAO implements DetalleFacturaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Tr_DetalleFactura t = new Tr_DetalleFactura();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Tr_DetalleFactura
        ArrayList<Tr_DetalleFactura> list = new ArrayList<>();
        String sql = "select * from tr_detalle_factura";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_DetalleFactura dfac = new Tr_DetalleFactura();
                dfac.setCodigo(rs.getInt("df_codigo")); 
                dfac.setSecuencial(rs.getInt("df_secuencial"));
                dfac.setProducto(rs.getInt("df_producto")); 
                dfac.setCantidad(rs.getDouble("df_cantidad"));                
                dfac.setValor(rs.getDouble("df_valor"));  
                dfac.setEstado(rs.getString("df_estado"));
                list.add(dfac);
            }
        } catch (Exception e) {
        }
        return list;
    }
      
    @Override
    public List listarDetalle() {
        //Metetodo que consulta la lista de Tr_DetalleFactura
        ArrayList<Tr_DetalleFactura> list = new ArrayList<>();
        int i = 1;
            while(i <= 5){
                Tr_DetalleFactura dfac = new Tr_DetalleFactura();                
                dfac.setSecuencial(i);                          
                dfac.setValor(0.00);  
                list.add(dfac);
                i = i + 1;
            }
        
        return list;
    }
   
    @Override
    public List listarDetalle(int factura) {
        //Metetodo que consulta la lista de Tr_DetalleFactura
        ArrayList<Tr_DetalleFactura> list = new ArrayList<>();
        String sql = "select df_secuencial,pr_producto,pr_descripcion,df_cantidad,df_valor from tr_detalle_factura,cl_producto \n" +
                     "where df_producto = pr_codigo\n" +
                     "and df_codigo ="+factura+" order by df_secuencial";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_DetalleFactura dfac = new Tr_DetalleFactura();                
                dfac.setSecuencial(rs.getInt("df_secuencial"));
                dfac.setEstado(rs.getString(2)); 
                dfac.setDescripcion(rs.getString(3));
                dfac.setCantidad(rs.getDouble("df_cantidad"));                
                dfac.setValor(rs.getDouble("df_valor"));  
                
                list.add(dfac);
            }
        } catch (Exception e) {
            System.out.println("Error listarDetalle:"+e.getMessage());
        }                
        return list;
    }

    @Override
    public boolean add(Tr_DetalleFactura detFactura) {
        //Metodo que agrega un Ad_Transaccion        
        detFactura.setCodigo(1);
        detFactura.setSecuencial(1);
        detFactura.setProducto(1);
        detFactura.setCantidad(0.00);
        detFactura.setValor(0.00);
        detFactura.setEstado("V");
        String sql = "insert into tr_detalle_factura(df_codigo,df_secuencial,df_producto,df_cantidad,df_valor,df_estado) values ('"+
                detFactura.getCodigo()+"','"+ 
                detFactura.getSecuencial()+"','"+ 
                detFactura.getProducto()+"','"+   
                detFactura.getCantidad()+"','"+   
                detFactura.getValor()+"','"+ 
                detFactura.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }    
    
}
