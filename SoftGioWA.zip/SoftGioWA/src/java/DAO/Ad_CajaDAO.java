/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.CajaCRUD;
import Model.Ad_Caja;
import Model.Ad_Tabla;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Ad_CajaDAO implements CajaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;
    Ad_Caja c = new Ad_Caja();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Ad_Caja> list = new ArrayList<>();
        String sql = "select * from ad_caja";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Caja caj = new Ad_Caja();
                caj.setCodigo(rs.getInt("ca_codigo"));
                caj.setNombre(rs.getString("ca_nombre"));
                caj.setOficina(rs.getInt("ca_oficina"));                
                caj.setFecha(rs.getDate("ca_fecha"));
                caj.setEstado(rs.getString("ca_estado"));
                list.add(caj);
            }
        } catch (Exception e) {
        }
        return list;
    }   
    
    @Override
    public List listarCajaUsuario(int oficina,int usuario) {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Ad_Caja> list = new ArrayList<>();
        String sql = "select * from ad_caja where ca_codigo in (select ur_caja from ad_usuario_rol where ur_oficina ="+ oficina+" and ur_usuario ="+usuario+")";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Caja caj = new Ad_Caja();
                caj.setCodigo(rs.getInt("ca_codigo"));
                caj.setNombre(rs.getString("ca_nombre"));               
                list.add(caj);
            }
        } catch (Exception e) {
        }
        return list;
    }  
    @Override
    public List listarCajaAbiertaUsuario(int oficina,int usuario) {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Ad_Caja> list = new ArrayList<>();
        String sql = "select * from ad_caja where ca_codigo in (select ac_caja from tr_apertura_caja where ac_oficina ="+ oficina+" and ac_usuario="+usuario+" and ac_estado='A')";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Caja caj = new Ad_Caja();
                caj.setCodigo(rs.getInt("ca_codigo"));
                caj.setNombre(rs.getString("ca_nombre"));               
                list.add(caj);
            }
        } catch (Exception e) {
        }
        return list;
    }  
    
    @Override
    public List listarCajas() {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Ad_Caja> list = new ArrayList<>();
        String sql = "select * from ad_caja";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Caja caj = new Ad_Caja();
                caj.setCodigo(rs.getInt("ca_codigo"));
                caj.setNombre(rs.getString("ca_nombre"));               
                list.add(caj);
            }
        } catch (Exception e) {
        }
        return list;
    } 

    @Override
    public Ad_Caja list(int codigo) {
        //Metodo que consulta una Caja       
        String sql = "select * from ad_caja where ca_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                c.setCodigo(rs.getInt("ca_codigo"));
                c.setNombre(rs.getString("ca_nombre"));
                c.setOficina(rs.getInt("ca_oficina"));                
                c.setFecha(rs.getDate("ca_fecha"));
                c.setEstado(rs.getString("ca_estado"));
                
            }
        } catch (Exception e) {
        }
        return c;
    }

    @Override
    public boolean add(Ad_Caja caj) {
        //Metodo que agrega una Caja
        Date fecha = new Date();
        caj.setFecha(fecha);
        caj.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("ad_caja");
        tabla.setCampo("ca_codigo");
        caj.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into ad_caja(ca_codigo,ca_nombre,ca_oficina,ca_fecha,ca_estado) values ('"+
                caj.getCodigo()+"','"+
                caj.getNombre()+"','"+
                caj.getOficina()+"',NOW(),'"+                
                caj.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_Caja caj) {
        //Metodo que actualiza una Caja
        Date fecha = new Date();
        caj.setFecha(fecha);
        caj.setEstado("V");
        String sql = "update ad_caja set ca_nombre ='"+caj.getNombre()+"', "
                + "ca_oficina='"+caj.getOficina()+"',"
                + "ca_fecha= NOW(),"
                + "ca_estado='"+caj.getEstado()+"' where ca_codigo ="+caj.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from ad_caja where ca_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public int validar(Ad_Caja caj) {
        String sql = "Select * from ad_caja where ca_codigo =?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, caj.getCodigo());
            //ps.setString(2, usr.getPassword());
            rs = ps.executeQuery();
            r = 0;
            while(rs.next()){
                r = r + 1;
                caj.setNombre(rs.getString("ca_nombre"));                
            }
            if(r==1){
                return 1;
            }else{
                return 0;
            }
            
        } catch (Exception e) {
            return 0;
        }
        
    }
    
    
}
