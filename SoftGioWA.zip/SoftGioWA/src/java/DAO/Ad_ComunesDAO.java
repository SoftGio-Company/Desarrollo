/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.ComunesCRUD;
import Model.Ad_Tabla;
import Model.Ad_Catalogo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author gcueva
 */
public class Ad_ComunesDAO implements ComunesCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;
    Ad_Tabla u = new Ad_Tabla();    
    @Override
    public int getCodigo(Ad_Tabla tabla) {
        String campo = "max("+tabla.getCampo()+")";
        String sql = "Select "+campo+" from "+tabla.getTabla();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();
            r = 0;
            while(rs.next()){
                r = r + 1;
                if(rs.getString(campo)!=null)
                {
                  tabla.setCodigo(Integer.parseInt(rs.getString(campo))+1);  
                }
                else
                {
                    tabla.setCodigo(r);
                }
            }
            if(r==1){
                return tabla.getCodigo();
            }else{
                return 1;
            }
            
        } catch (Exception e) {
            return 0;
        }
        
    }
    @Override
    public String getDescripcion(Ad_Tabla tabla) {
        
        String sql = "Select "+tabla.getCampo()+" from "+tabla.getTabla()+" where "+tabla.getCampoCodigo()+"="+tabla.getCodigo();
        tabla.setDescripcion("");
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();            
            while(rs.next()){                
                if(rs.getString(tabla.getCampo())!=null)
                {
                  tabla.setDescripcion(rs.getString(tabla.getCampo()));  
                }
                else
                {
                    tabla.setDescripcion("");
                }
            }
            
            
        } catch (Exception e) {
            return "";
        }
        return tabla.getDescripcion();
    }
    
    @Override
    public List catalogo(String tabla) {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Ad_Catalogo> list = new ArrayList<>();
        String sql = "select * from cl_catalogo where ca_tabla = (select ta_codigo from cl_tabla where ta_nombre ='"+tabla+"') and ca_estado = 'V'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Catalogo cat = new Ad_Catalogo();
                cat.setCodigo(rs.getInt("ca_codigo"));
                cat.setTabla(rs.getInt("ca_tabla"));
                cat.setValor(rs.getString("ca_valor"));
                cat.setDescripcion(rs.getString("ca_descripcion"));   
                list.add(cat);
            }
        } catch (Exception e) {
        }
        return list;
    }  
    
}
