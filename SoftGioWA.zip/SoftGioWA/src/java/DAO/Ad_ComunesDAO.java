/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.ComunesCRUD;
import Model.Ad_Tabla;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 *
 * @author gcueva
 */
public class Ad_ComunesDAO implements ComunesCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;
    Ad_Tabla u = new Ad_Tabla();    
    @Override
    public int getCodigo(Ad_Tabla tabla) {
        String campo = "max("+tabla.getCampo()+")";
        String sql = "Select "+campo+" from "+tabla.getTabla();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();
            r = 0;
            while(rs.next()){
                r = r + 1;
                if(rs.getString(campo)!=null)
                {
                  tabla.setCodigo(Integer.parseInt(rs.getString(campo))+1);  
                }
                else
                {
                    tabla.setCodigo(r);
                }
            }
            if(r==1){
                return tabla.getCodigo();
            }else{
                return 1;
            }
            
        } catch (Exception e) {
            return 0;
        }
        
    }
    
    
    
}
