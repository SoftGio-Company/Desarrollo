/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.ProductoCRUD;
import Model.Ad_Tabla;
import Model.Cl_Producto;
import Model.Cl_Producto_His;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_ProductoDAO implements ProductoCRUD {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Producto p = new Cl_Producto();

    @Override
    public List listar(String codigoPro, String nombrePro, String descripcionPro) {
        //Metetodo que consulta la lista de Usuarios
         if(codigoPro == null || (nombrePro != "" || descripcionPro != ""))
            codigoPro = "0";
        ArrayList<Cl_Producto> list = new ArrayList<>();
        String sql = "select * from cl_producto where pr_producto like '%"+nombrePro+"%' and pr_descripcion like'%"+descripcionPro+"%' and pr_codigo > "+codigoPro+"  order by pr_codigo asc limit 20";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cl_Producto pro = new Cl_Producto();
                pro.setCodigo(rs.getInt("pr_codigo"));
                pro.setProducto(rs.getString("pr_producto"));
                pro.setDescripcion(rs.getString("pr_descripcion"));
                pro.setPrecio(rs.getDouble("pr_precio"));
                pro.setCantidad(rs.getDouble("pr_cantidad"));
                pro.setFecha(rs.getDate("pr_fecha"));
                pro.setEstado(rs.getString("pr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List inventario( String fechaIni, String fechaFin) {
        //Metetodo que consulta la lista de Inventario
        String sql = "";
        if(!fechaIni.isEmpty() && !fechaFin.isEmpty())
        {            
            sql = "Select ph_codigo,ph_fecha,ph_cod_producto,pr_producto,pr_descripcion,ph_precio,ph_cantidad_ini,ph_cantidad_ing,ph_cantidad_egr from  cl_producto_his,cl_producto where pr_codigo = ph_cod_producto and Date(ph_fecha) BETWEEN '"+fechaIni+"' AND '"+fechaFin+"' order by ph_codigo asc";
        }
        else
        {
            sql = "Select ph_codigo,ph_fecha,ph_cod_producto,pr_producto,pr_descripcion,ph_precio,ph_cantidad_ini,ph_cantidad_ing,ph_cantidad_egr from  cl_producto_his,cl_producto where pr_codigo = ph_cod_producto and ph_fecha = current_date()  order by ph_codigo asc";
        }        
            
        ArrayList<Cl_Producto_His> list = new ArrayList<>();
        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cl_Producto_His proHis = new Cl_Producto_His();
                proHis.setCodigo(rs.getInt("ph_codigo"));
                proHis.setFecha(rs.getDate("ph_fecha"));
                proHis.setCodigoProducto(rs.getInt("ph_cod_producto"));
                proHis.setPrecio(rs.getDouble("ph_precio"));
                proHis.setCantInicial(rs.getDouble("ph_cantidad_ini"));
                proHis.setCantIngreso(rs.getDouble("ph_cantidad_ing"));
                proHis.setCantEgreso(rs.getDouble("ph_cantidad_egr"));
                proHis.setProducto(rs.getString("pr_producto"));
                proHis.setDescripcion(rs.getString("pr_descripcion"));
                list.add(proHis);
            }
        } catch (Exception e) {
        }
        return list;
    }
    @Override
    public List listarProductos(String codigoPro, String nombrePro, String descripcionPro) {
        //Metetodo que consulta la lista de Usuarios
         if(codigoPro == null || (nombrePro != "" || descripcionPro != ""))
            codigoPro = "0";
        ArrayList<Cl_Producto> list = new ArrayList<>();
        String sql = "select * from cl_producto where pr_producto like '%"+nombrePro+"%' and pr_descripcion like'%"+descripcionPro+"%' and pr_codigo > "+codigoPro+"  order by pr_cantidad asc limit 10";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cl_Producto pro = new Cl_Producto();
                pro.setCodigo(rs.getInt("pr_codigo"));
                pro.setProducto(rs.getString("pr_producto"));
                pro.setDescripcion(rs.getString("pr_descripcion"));
                pro.setPrecio(rs.getDouble("pr_precio"));
                pro.setCantidad(rs.getDouble("pr_cantidad"));
                pro.setFecha(rs.getDate("pr_fecha"));
                pro.setEstado(rs.getString("pr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
   @Override
    public List consultarProductos(String nombrePro, String descripcionPro) {
        //Metetodo que consulta la lista de Productos 
        String sql = "";
        if(nombrePro != "" || descripcionPro != "")
         sql = "select * from cl_producto where pr_producto like '%"+nombrePro+"%' and pr_descripcion like'%"+descripcionPro+"%' order by pr_cantidad asc limit 10";
        else
         sql = "select * from cl_producto order by pr_cantidad asc limit 10";        
        ArrayList<Cl_Producto> list = new ArrayList<>();        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cl_Producto pro = new Cl_Producto();
                pro.setCodigo(rs.getInt("pr_codigo"));
                pro.setProducto(rs.getString("pr_producto"));
                pro.setDescripcion(rs.getString("pr_descripcion"));
                pro.setPrecio(rs.getDouble("pr_precio"));
                pro.setCantidad(rs.getDouble("pr_cantidad"));
                pro.setFecha(rs.getDate("pr_fecha"));
                pro.setEstado(rs.getString("pr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
    @Override
    public Cl_Producto list(int codigo) {
        //Metodo que consulta un Producto 
        Integer cod = new Integer(0);
        p = new Cl_Producto();
        if (cod == codigo) {
            p.setCodigo(0);
            p.setProducto("");
            p.setDescripcion("");
            p.setPrecio(0.00);
            p.setCantidad(0.00);
        } else {
            String sql = "select * from cl_producto where pr_codigo =" + codigo;
            try {
                con = cn.getConnection();
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {

                    p.setCodigo(rs.getInt("pr_codigo"));
                    p.setProducto(rs.getString("pr_producto"));
                    p.setDescripcion(rs.getString("pr_descripcion"));
                    p.setPrecio(rs.getDouble("pr_precio"));
                    p.setCantidad(rs.getDouble("pr_cantidad"));
                    p.setFecha(rs.getDate("pr_fecha"));
                    p.setEstado(rs.getString("pr_estado"));

                }
            } catch (Exception e) {
            }
        }
        return p;
    }

    @Override
    public Cl_Producto buscar(String producto) {
        //Metodo que consulta un Producto       
        String sql = "select pr_codigo,pr_producto,pr_descripcion,pr_precio,pr_cantidad from cl_producto where pr_producto ='" + producto + "'";
        p = new Cl_Producto();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                p.setCodigo(rs.getInt("pr_codigo"));
                p.setProducto(rs.getString("pr_producto"));
                p.setDescripcion(rs.getString("pr_descripcion"));
                p.setPrecio(rs.getDouble("pr_precio"));
                p.setCantidad(rs.getDouble("pr_cantidad"));
            }
        } catch (Exception e) {
        }
        return p;
    }

    @Override
    public boolean add(Cl_Producto pro) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_producto");
        tabla.setCampo("pr_codigo");
        pro.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_producto(pr_codigo,pr_producto,pr_descripcion,pr_precio,pr_cantidad,pr_fecha,pr_estado) values ('"
                + pro.getCodigo() + "','"
                + pro.getProducto() + "','"
                + pro.getDescripcion() + "','"
                + pro.getPrecio() + "','"
                + pro.getCantidad() + "',NOW(),'"
                + pro.getEstado() + "')";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Producto pro) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        String sql = "update cl_producto set pr_producto ='" + pro.getProducto() + "', "
                + "pr_descripcion='" + pro.getDescripcion() + "',"
                + "pr_precio='" + pro.getPrecio() + "',"
                + "pr_cantidad='" + pro.getCantidad() + "',"
                + "pr_estado='" + pro.getEstado() + "' where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }
    @Override
    public boolean agregar(Cl_Producto pro) {
        //Metodo que agregar canidad a un Producto
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        Double cantidad = 0.00;
        cantidad = pro.getCantidad();
        //Metodo que consulta un Producto       
        String sql = "select * from cl_producto where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                p.setCodigo(rs.getInt("pr_codigo"));
                p.setProducto(rs.getString("pr_producto"));
                p.setDescripcion(rs.getString("pr_descripcion"));
                p.setPrecio(rs.getDouble("pr_precio"));
                p.setCantidad(rs.getDouble("pr_cantidad"));
                p.setFecha(rs.getDate("pr_fecha"));
                p.setEstado(rs.getString("pr_estado"));
            }
        } catch (Exception e) {
        }
        sql = "update cl_producto set pr_cantidad ='" + (p.getCantidad() + cantidad) + "' where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        Cl_Producto_His ph = new Cl_Producto_His();
        sql = "select * from cl_producto_his where ph_fecha = current_date() and ph_cod_producto =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ph.setCodigo(rs.getInt("ph_codigo"));    
                ph.setCantIngreso(rs.getDouble("ph_cantidad_ing"));
                ph.setCantEgreso(rs.getDouble("ph_cantidad_egr"));
            }
        } catch (Exception e) {
        }
        if (ph.getCodigo() > 0){
            
            sql = "update cl_producto_his set ph_cantidad_ing ="+(cantidad+ph.getCantIngreso())+ 
                     " where ph_fecha = current_date() and ph_codigo="+ph.getCodigo();
            try {
                con = cn.getConnection();
                ps  = con.prepareStatement(sql);
                ps.executeUpdate();
            } catch (Exception e) {
                return false;
            }
        }
        else{            
            //Genera Nuevo Codigo
            Ad_ComunesDAO comunes = new Ad_ComunesDAO();
            Ad_Tabla tabla = new Ad_Tabla();
            tabla.setTabla("cl_producto_his");
            tabla.setCampo("ph_codigo");
            ph.setCodigo(comunes.getCodigo(tabla));
            
            sql = "insert into cl_producto_his(ph_codigo,ph_fecha,ph_cod_producto,ph_precio,ph_cantidad_ini,ph_cantidad_ing,ph_cantidad_egr) values ('"+
                ph.getCodigo()+"',NOW(),'"+                 
                p.getCodigo()+"','"+ 
                p.getPrecio()+"','"+ 
                p.getCantidad()+"','"+
                cantidad+"','0.00')";
            try {
                con = cn.getConnection();
                ps  = con.prepareStatement(sql);
                ps.executeUpdate();

            } catch (Exception e) {
            }        
        }        
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_producto where pr_codigo =" + codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean updateCantidad(Cl_Producto pro) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        Double cantidadUpdate = pro.getCantidad();
        //Metodo que consulta un Producto       
        String sql = "select * from cl_producto where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                p.setCodigo(rs.getInt("pr_codigo"));
                p.setProducto(rs.getString("pr_producto"));
                p.setDescripcion(rs.getString("pr_descripcion"));
                p.setPrecio(rs.getDouble("pr_precio"));
                p.setCantidad(rs.getDouble("pr_cantidad"));
                p.setFecha(rs.getDate("pr_fecha"));
                p.setEstado(rs.getString("pr_estado"));
            }
        } catch (Exception e) {
        }
        sql = "update cl_producto set pr_cantidad ='" + (p.getCantidad() - cantidadUpdate) + "' where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        Cl_Producto_His ph = new Cl_Producto_His();
        sql = "select * from cl_producto_his where ph_fecha = current_date() and ph_cod_producto =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                ph.setCodigo(rs.getInt("ph_codigo"));    
                ph.setCantIngreso(rs.getDouble("ph_cantidad_ing"));
                ph.setCantEgreso(rs.getDouble("ph_cantidad_egr"));
            }
        } catch (Exception e) {
        }
        if (ph.getCodigo() > 0){
            
            sql = "update cl_producto_his set ph_cantidad_egr ="+(cantidadUpdate+ph.getCantEgreso())+ 
                     " where ph_fecha = current_date() and ph_codigo="+ph.getCodigo();
            try {
                con = cn.getConnection();
                ps  = con.prepareStatement(sql);
                ps.executeUpdate();
            } catch (Exception e) {
                return false;
            }
        }
        else{            
            //Genera Nuevo Codigo
            Ad_ComunesDAO comunes = new Ad_ComunesDAO();
            Ad_Tabla tabla = new Ad_Tabla();
            tabla.setTabla("cl_producto_his");
            tabla.setCampo("ph_codigo");
            ph.setCodigo(comunes.getCodigo(tabla));
            
            sql = "insert into cl_producto_his(ph_codigo,ph_fecha,ph_cod_producto,ph_precio,ph_cantidad_ini,ph_cantidad_ing,ph_cantidad_egr) values ('"+
                ph.getCodigo()+"',NOW(),'"+                 
                p.getCodigo()+"','"+ 
                p.getPrecio()+"','"+ 
                p.getCantidad()+"','0.00','"+   
                cantidadUpdate+"')";
            try {
                con = cn.getConnection();
                ps  = con.prepareStatement(sql);
                ps.executeUpdate();

            } catch (Exception e) {
            }        
        }        
        return false;
    }
}
