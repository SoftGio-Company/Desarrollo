/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.ProductoCRUD;
import Model.Ad_Tabla;
import Model.Cl_Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_ProductoDAO implements ProductoCRUD {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Producto p = new Cl_Producto();

    @Override
    public List listar(String codigoPro, String nombrePro, String descripcionPro) {
        //Metetodo que consulta la lista de Usuarios
         if(codigoPro == null || (nombrePro != "" || descripcionPro != ""))
            codigoPro = "0";
        ArrayList<Cl_Producto> list = new ArrayList<>();
        String sql = "select * from cl_producto where pr_producto like '%"+nombrePro+"%' and pr_descripcion like'%"+descripcionPro+"%' and pr_codigo > "+codigoPro+"  order by pr_codigo asc limit 10";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cl_Producto pro = new Cl_Producto();
                pro.setCodigo(rs.getInt("pr_codigo"));
                pro.setProducto(rs.getString("pr_producto"));
                pro.setDescripcion(rs.getString("pr_descripcion"));
                pro.setPrecio(rs.getDouble("pr_precio"));
                pro.setCantidad(rs.getDouble("pr_cantidad"));
                pro.setFecha(rs.getDate("pr_fecha"));
                pro.setEstado(rs.getString("pr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List listarProductos(String codigoPro, String nombrePro, String descripcionPro) {
        //Metetodo que consulta la lista de Usuarios
         if(codigoPro == null || (nombrePro != "" || descripcionPro != ""))
            codigoPro = "0";
        ArrayList<Cl_Producto> list = new ArrayList<>();
        String sql = "select * from cl_producto where pr_producto like '%"+nombrePro+"%' and pr_descripcion like'%"+descripcionPro+"%' and pr_codigo > "+codigoPro+"  order by pr_cantidad asc limit 10";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cl_Producto pro = new Cl_Producto();
                pro.setCodigo(rs.getInt("pr_codigo"));
                pro.setProducto(rs.getString("pr_producto"));
                pro.setDescripcion(rs.getString("pr_descripcion"));
                pro.setPrecio(rs.getDouble("pr_precio"));
                pro.setCantidad(rs.getDouble("pr_cantidad"));
                pro.setFecha(rs.getDate("pr_fecha"));
                pro.setEstado(rs.getString("pr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Cl_Producto list(int codigo) {
        //Metodo que consulta un Producto 
        Integer cod = new Integer(0);
        p = new Cl_Producto();
        if (cod == codigo) {
            p.setCodigo(0);
            p.setProducto("");
            p.setDescripcion("");
            p.setPrecio(0.00);
            p.setCantidad(0.00);
        } else {
            String sql = "select * from cl_producto where pr_codigo =" + codigo;
            try {
                con = cn.getConnection();
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();
                while (rs.next()) {

                    p.setCodigo(rs.getInt("pr_codigo"));
                    p.setProducto(rs.getString("pr_producto"));
                    p.setDescripcion(rs.getString("pr_descripcion"));
                    p.setPrecio(rs.getDouble("pr_precio"));
                    p.setCantidad(rs.getDouble("pr_cantidad"));
                    p.setFecha(rs.getDate("pr_fecha"));
                    p.setEstado(rs.getString("pr_estado"));

                }
            } catch (Exception e) {
            }
        }
        return p;
    }

    @Override
    public Cl_Producto buscar(String producto) {
        //Metodo que consulta un Producto       
        String sql = "select pr_codigo,pr_producto,pr_descripcion,pr_precio,pr_cantidad from cl_producto where pr_producto ='" + producto + "'";
        p = new Cl_Producto();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                p.setCodigo(rs.getInt("pr_codigo"));
                p.setProducto(rs.getString("pr_producto"));
                p.setDescripcion(rs.getString("pr_descripcion"));
                p.setPrecio(rs.getDouble("pr_precio"));
                p.setCantidad(rs.getDouble("pr_cantidad"));
            }
        } catch (Exception e) {
        }
        return p;
    }

    @Override
    public boolean add(Cl_Producto pro) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_producto");
        tabla.setCampo("pr_codigo");
        pro.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_producto(pr_codigo,pr_producto,pr_descripcion,pr_precio,pr_cantidad,pr_fecha,pr_estado) values ('"
                + pro.getCodigo() + "','"
                + pro.getProducto() + "','"
                + pro.getDescripcion() + "','"
                + pro.getPrecio() + "','"
                + pro.getCantidad() + "',NOW(),'"
                + pro.getEstado() + "')";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Producto pro) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        String sql = "update cl_producto set pr_producto ='" + pro.getProducto() + "', "
                + "pr_descripcion='" + pro.getDescripcion() + "',"
                + "pr_precio='" + pro.getPrecio() + "',"
                + "pr_cantidad='" + pro.getCantidad() + "',"
                + "pr_estado='" + pro.getEstado() + "' where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_producto where pr_codigo =" + codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean updateCantidad(Cl_Producto pro) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        //Metodo que consulta un Producto       
        String sql = "select * from cl_producto where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {

                p.setCodigo(rs.getInt("pr_codigo"));
                p.setProducto(rs.getString("pr_producto"));
                p.setDescripcion(rs.getString("pr_descripcion"));
                p.setPrecio(rs.getDouble("pr_precio"));
                p.setCantidad(rs.getDouble("pr_cantidad"));
                p.setFecha(rs.getDate("pr_fecha"));
                p.setEstado(rs.getString("pr_estado"));

            }
        } catch (Exception e) {
        }
        sql = "update cl_producto set pr_cantidad ='" + (p.getCantidad() - pro.getCantidad()) + "' where pr_codigo =" + pro.getCodigo();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();

        } catch (Exception e) {
        }
        return false;
    }

}
