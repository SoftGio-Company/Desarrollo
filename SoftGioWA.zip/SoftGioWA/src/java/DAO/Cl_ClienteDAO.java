/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.ClienteCRUD;
import Model.Ad_Tabla;
import Model.Cl_Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_ClienteDAO implements ClienteCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Cliente c = new Cl_Cliente();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Usuarios
        ArrayList<Cl_Cliente> list = new ArrayList<>();
        String sql = "select * from cl_cliente";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Cl_Cliente cli = new Cl_Cliente();
                cli.setCodigo(rs.getInt("cl_codigo"));
                cli.setIdentificacion(rs.getString("cl_identificacion"));
                cli.setNombre(rs.getString("cl_nombre"));
                cli.setApellido(rs.getString("cl_apellido"));
                cli.setDireccion(rs.getString("cl_direccion"));
                cli.setTelefono(rs.getString("cl_telefono"));
                cli.setEmail(rs.getString("cl_email"));
                cli.setFecha(rs.getDate("cl_fecha"));
                cli.setEstado(rs.getString("cl_estado"));
                list.add(cli);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Cl_Cliente list(int codigo) {
        //Metodo que consulta un Usuario        
        String sql = "select * from cl_cliente where cl_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                c.setCodigo(rs.getInt("cl_codigo"));
                c.setIdentificacion(rs.getString("cl_identificacion"));
                c.setNombre(rs.getString("cl_nombre"));
                c.setApellido(rs.getString("cl_apellido"));
                c.setDireccion(rs.getString("cl_direccion"));
                c.setTelefono(rs.getString("cl_telefono"));
                c.setEmail(rs.getString("cl_email"));
                c.setFecha(rs.getDate("cl_fecha"));
                c.setEstado(rs.getString("cl_estado"));
                
            }
        } catch (Exception e) {
        }
        return c;
    }
    @Override
    public Cl_Cliente buscar(String cedula) {       
        String sql = "Select cl_codigo,cl_identificacion,cl_nombre,cl_apellido,cl_direccion,cl_telefono,cl_email from cl_cliente where cl_identificacion ="+cedula;
        c = new Cl_Cliente();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();
            c.setIdentificacion(cedula);
           while(rs.next()){
            c.setCodigo(rs.getInt("cl_codigo"));
            c.setIdentificacion(rs.getString("cl_identificacion"));
            c.setNombre(rs.getString("cl_nombre"));
            c.setApellido(rs.getString("cl_apellido"));
            c.setDireccion(rs.getString("cl_direccion"));
            c.setTelefono(rs.getString("cl_telefono"));
            c.setEmail(rs.getString("cl_email"));           
            }
            
        } catch (Exception e) {
            
        }
        return c;
    }

    @Override
    public boolean add(Cl_Cliente cli) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        cli.setFecha(fecha);
        cli.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_cliente");
        tabla.setCampo("cl_codigo");
        cli.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_cliente(cl_codigo,cl_identificacion,cl_nombre,cl_apellido,cl_direccion,cl_telefono,cl_email,cl_fecha,cl_estado) values ('"+
                cli.getCodigo()+"','"+
                cli.getIdentificacion()+"','"+
                cli.getNombre()+"','"+
                cli.getApellido()+"','"+
                cli.getDireccion()+"','"+
                cli.getTelefono()+"','"+ 
                cli.getEmail()+"',NOW(),'"+ 
                cli.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Cliente cli) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        cli.setFecha(fecha);
        cli.setEstado("V");
        String sql = "update cl_cliente set cl_identificacion ='"+cli.getIdentificacion()+"', "
                + "cl_nombre='"+cli.getNombre()+"',"
                + "cl_apellido='"+cli.getApellido()+"',"
                + "cl_direccion='"+cli.getDireccion()+"',"
                + "cl_telefono='"+cli.getTelefono()+"',"
                + "cl_email='"+cli.getEmail()+"',"
                + "cl_estado='"+cli.getEstado()+"' where cl_codigo ="+cli.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_cliente where cl_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
