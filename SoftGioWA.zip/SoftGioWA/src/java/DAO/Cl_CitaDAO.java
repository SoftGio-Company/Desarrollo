/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.CitaCRUD;
import Model.Ad_Tabla;
import Model.Cl_Cita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_CitaDAO implements CitaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Cita c = new Cl_Cita();
    
    @Override
    public List listar(String codigo) {
        //Metetodo que consulta la lista de Usuarios

        ArrayList<Cl_Cita> list = new ArrayList<>();
        String sql = "select * from cl_cita where ci_cliente ="+codigo+"  and ci_codigo > 0  order by ci_codigo asc limit 20";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Cl_Cita his = new Cl_Cita();
                his.setCodigo(rs.getInt("ci_codigo"));
                his.setFecha(rs.getDate("ci_fecha"));
                his.setOficina(rs.getInt("ci_oficina"));                
                his.setCliente(rs.getInt("ci_cliente"));
                his.setMedico(rs.getInt("ci_medico"));
                his.setFechaCita(rs.getDate("ci_fecha_cita"));
                his.setHoraInicio(rs.getTime("ci_hora_ini"));
                his.setHoraFin(rs.getTime("ci_hora_fin"));
                his.setTipo(rs.getString("ci_tipo"));  
                his.setEstado(rs.getString("ci_estado"));  
                
                list.add(his);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Cl_Cita list(int codigo) {
        //Metodo que consulta un Usuario   
        Integer cod = new Integer(0);
        c = new Cl_Cita();        
        if(cod == codigo){            
            c.setCodigo(0);
            c.setFecha(null);
            c.setOficina(0);
            c.setCliente(0);
            c.setUsuario(0);
            c.setMedico(0);
            c.setFechaCita(null);
            c.setHoraInicio(null);
            c.setHoraFin(null);
            c.setTipo("");
            c.setEstado("");
        }
        else{
        String sql = "select * from cl_cita where ci_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                
                c.setCodigo(rs.getInt("ci_codigo"));
                c.setFecha(rs.getDate("ci_fecha"));
                c.setOficina(rs.getInt("ci_oficina"));
                c.setUsuario(rs.getInt("ci_usuario"));
                c.setCliente(rs.getInt("ci_cliente"));
                c.setMedico(rs.getInt("ci_medico"));
                c.setFechaCita(rs.getDate("hi_fecha_cita"));
                c.setHoraInicio(rs.getTime("hi_hora_ini"));
                c.setHoraFin(rs.getTime("hi_hora_fin"));
                c.setTipo(rs.getString("hi_tipo"));
                c.setEstado(rs.getString("hi_estado"));                
            }
        } catch (Exception e) {
        }
        }
        return c;
    }
    @Override
    public Cl_Cita buscar(String cedula) {       
        String sql = "Select * from cl_cita where ci_cliente = (select cl_codigo from cl_cliente where cl_identificacion ="+cedula+")";
        c = new Cl_Cita();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();            
           while(rs.next()){
                c.setCodigo(rs.getInt("ci_codigo"));
                c.setFecha(rs.getDate("ci_identificacion"));
                c.setOficina(rs.getInt("ci_oficina"));
                c.setUsuario(rs.getInt("ci_usuario"));
                c.setCliente(rs.getInt("ci_cliente"));
                c.setMedico(rs.getInt("ci_medico"));
                c.setFechaCita(rs.getDate("ci_fecha_cita"));
                c.setHoraInicio(rs.getTime("ci_hora_ini"));
                c.setHoraFin(rs.getTime("ci_hora_fin"));
                c.setTipo(rs.getString("ci_tipo"));
                c.setEstado(rs.getString("ci_estado"));           
            }
            
        } catch (Exception e) {
            
        }
        return c;
    }

    @Override
    public boolean add(Cl_Cita cit) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();        
        cit.setFecha(fecha);        
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_cita");
        tabla.setCampo("ci_codigo");
        cit.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_cita(ci_codigo,ci_fecha,ci_oficina,ci_usuario,ci_cliente,ci_medico,ci_fecha_cita,ci_hora_ini,ci_hora_fin,ci_tipo,ci_estado) values ('"+
                cit.getCodigo()+"',NOW(),'"+  
                cit.getOficina()+"','"+
                cit.getUsuario()+"','"+
                cit.getCliente()+"','"+
                cit.getMedico()+"','"+ 
                cit.getFechaCita()+"','"+ 
                cit.getHoraInicio()+"','"+ 
                cit.getHoraFin()+"','"+ 
                cit.getTipo()+"','"+                
                cit.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Cita cit) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        cit.setFecha(fecha);        
        String sql = "update cl_cita set ci_tipo ='"+cit.getTipo()+"', "
                + "ci_fecha_cita='"+cit.getFechaCita()+"',"
                + "ci_hora_ini='"+cit.getHoraInicio()+"',"
                + "ci_hora_fin='"+cit.getHoraFin()+","
                + "ci_estado='"+cit.getEstado()+"' where ci_codigo ="+cit.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_cita where ci_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
