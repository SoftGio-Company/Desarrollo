/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.FacturaCRUD;
import Model.Ad_Tabla;
import Model.Tr_TransaccionMonetaria;
import Model.Tr_Factura;
import Model.Tr_DetalleFactura;
import Model.Cl_Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Tr_FacturaDAO implements FacturaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Tr_Factura f = new Tr_Factura();
    @Override
    public List listar(String codigo, String cedula, String fechaIni, String fechaFin) {
        //Metetodo que consulta la lista de Tr_Factura
        if(codigo == null || codigo.isEmpty())
            codigo = "0";
        ArrayList<Tr_Factura> list = new ArrayList<>();
        String sql = "select fc_codigo,fc_fecha,(select concat_ws(' ',cl_nombre,cl_apellido) from cl_cliente where cl_codigo = a.fc_cliente ),fc_subtotal,fc_iva,fc_total from tr_factura a where fc_codigo >= "+codigo;
        if(!cedula.isEmpty()){
            sql = sql + " and fc_cliente = (select cl_codigo from cl_cliente where cl_identificacion = '"+cedula+"')";
        }
        if(!fechaIni.isEmpty() && !fechaFin.isEmpty()){            
            sql = sql + " and Date(fc_fecha) BETWEEN '"+fechaIni+"' AND '"+fechaFin+"'";
        }        
        sql = sql + " limit 10";        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_Factura fac = new Tr_Factura();                
                fac.setCodigo(rs.getInt("fc_codigo"));                 
                fac.setFecha(rs.getDate("fc_fecha")); 
                fac.setEstado(rs.getString(3));
                fac.setSubtotal(rs.getDouble("fc_subtotal")); 
                fac.setIva(rs.getDouble("fc_iva"));  
                fac.setTotal(rs.getDouble("fc_total"));                 
                list.add(fac);
            }
        } catch (Exception e) {
        }
        return list;
    }   
    
    @Override
    public List list() {
        //Metetodo que consulta la lista de Tr_Factura
        ArrayList<Tr_Factura> list = new ArrayList<>();
        String sql = "select * from tr_factura limit 10";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_Factura fac = new Tr_Factura();
                fac.setCodTransaccion(rs.getInt("fc_transaccion"));
                fac.setCodigo(rs.getInt("fc_codigo"));                 
                fac.setFecha(rs.getDate("fc_fecha")); 
                fac.setCodCliente(rs.getInt("fc_cliente"));  
                fac.setCodCaja(rs.getInt("fc_caja"));
                fac.setUsuario(rs.getString("fc_usuario"));
                fac.setSubtotal(rs.getDouble("fc_subtotal")); 
                fac.setIva(rs.getDouble("fc_iva"));  
                fac.setTotal(rs.getDouble("fc_total")); 
                fac.setEstado(rs.getString("fc_estado"));
                list.add(fac);
            }
        } catch (Exception e) {
        }
        return list;
    }  
    
    @Override
    public Tr_Factura list(int codigo) {
        //Metetodo que consulta la lista de Tr_Factura        
        String sql = "select * from tr_factura where fc_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                
                f.setCodTransaccion(rs.getInt("fc_transaccion"));
                f.setCodigo(rs.getInt("fc_codigo"));                 
                f.setFecha(rs.getDate("fc_fecha")); 
                f.setCodCliente(rs.getInt("fc_cliente")); 
                f.setCodCaja(rs.getInt("fc_caja"));
                f.setUsuario(rs.getString("fc_usuario"));
                f.setSubtotal(rs.getDouble("fc_subtotal")); 
                f.setIva(rs.getDouble("fc_iva"));  
                f.setTotal(rs.getDouble("fc_total")); 
                f.setEstado(rs.getString("fc_estado"));                
            }
        } catch (Exception e) {
        }
        return f;
    }

    @Override
    public int add(Tr_Factura factura) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();        
        //Obtenemos el ultimo Codigo Generado
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("tr_transaccion_monetaria");
        tabla.setCampo("tm_secuencial");
        if(comunes.getCodigo(tabla)>1)
        {
            factura.setCodTransaccion(comunes.getCodigo(tabla)-1); 
        }
        else
        {
            factura.setCodTransaccion(comunes.getCodigo(tabla)); 
        }               
        //Genera Nuevo Codigo        
        tabla.setTabla("tr_factura");
        tabla.setCampo("fc_codigo");
        factura.setCodigo(comunes.getCodigo(tabla));
        //Guardamos la Transaccion Monetaria
        Tr_TransaccionMonetaria transaccionMonetaria = factura.getTransaccionMonetaria();
        transaccionMonetaria.setDescripcion("FACTURA NRO:"+factura.getCodigo());
        Tr_TransaccionMonetariaDAO transaccionMonetariaDAO = new Tr_TransaccionMonetariaDAO();
        transaccionMonetariaDAO.add(transaccionMonetaria);
        //Fin Genera Codigo                      
        factura.setCodCliente(factura.getCodCliente());
        factura.setCodCaja(factura.getCodCaja());
        factura.setUsuario(factura.getUsuario());
        factura.setSubtotal(factura.getSubtotal());
        factura.setIva(factura.getIva());
        factura.setTotal(factura.getTotal());
        factura.setDetalleFactura(factura.getDetalleFactura());
        factura.setEstado("V");
        String sql = "insert into tr_factura(fc_transaccion,fc_codigo,fc_fecha,fc_cliente,fc_caja,fc_usuario,fc_subtotal,fc_iva,fc_total,fc_estado) values ('"+
                factura.getCodTransaccion()+"','"+                  
                factura.getCodigo()+"',NOW(),'"+ 
                factura.getCodCliente()+"','"+ 
                factura.getCodCaja()+"','"+  
                factura.getUsuario()+"','"+  
                factura.getSubtotal()+"','"+
                factura.getIva()+"','"+
                factura.getTotal()+"','"+
                factura.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        List<Tr_DetalleFactura> detalle = factura.getDetalleFactura();
        for(int i=0; i<detalle.size();i++){
        sql = "insert into tr_detalle_factura(df_codigo,df_secuencial,df_producto,df_cantidad,df_valor,df_estado) values ('"+
                factura.getCodigo()+"','"+                  
                detalle.get(i).getSecuencial()+"','"+ 
                detalle.get(i).getCodigo()+"','"+   
                detalle.get(i).getCantidad()+"','"+
                detalle.get(i).getValor()+"','"+                
                detalle.get(i).getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        Cl_Producto producto = new Cl_Producto();
        producto.setCodigo(detalle.get(i).getCodigo());
        producto.setCantidad(detalle.get(i).getCantidad());
        Cl_ProductoDAO productoDao = new Cl_ProductoDAO();
        if(producto.getCodigo()>0){
            productoDao.updateCantidad(producto);
        }
        
        }
        return factura.getCodigo();
    }    
    
}
