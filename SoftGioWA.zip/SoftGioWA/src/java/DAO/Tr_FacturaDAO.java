/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.FacturaCRUD;
import Model.Ad_Tabla;
import Model.Tr_TransaccionMonetaria;
import Model.Tr_Factura;
import Model.Tr_DetalleFactura;
import Model.Cl_Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Tr_FacturaDAO implements FacturaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Tr_Factura f = new Tr_Factura();
    @Override
    public List listar(String codigo, String cedula, String fechaIni, String fechaFin,String estado) {
        //Metetodo que consulta la lista de Tr_Factura
        if(codigo == null || codigo.isEmpty())
            codigo = "0";
     
        ArrayList<Tr_Factura> list = new ArrayList<>();
        String sql = "select fa_codigo,fa_fecha,(select concat_ws(' ',cl_nombre,cl_apellido) from cl_cliente where cl_codigo = a.fa_cliente ),fa_estado,fa_subtotal,fa_iva,fa_total from tr_factura a where fa_codigo >= "+codigo;
        if(!cedula.isEmpty()){
            sql = sql + " and fa_cliente = (select cl_codigo from cl_cliente where cl_identificacion = '"+cedula+"')";
        }
        if (estado != null){
            if(estado.equals("P") || estado.equals("C") || estado.equals("A"))
            {
                sql = sql + " and fa_estado = '"+estado+"'";
            }
        }
        
        if(!fechaIni.isEmpty() && !fechaFin.isEmpty()){            
            sql = sql + " and Date(fa_fecha) BETWEEN '"+fechaIni+"' AND '"+fechaFin+"'";
        }
        else
        {
             sql = sql + " and fa_fecha = current_date()";
        
        }
               
        sql = sql + " limit 10";        
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_Factura fac = new Tr_Factura();                
                fac.setCodigo(rs.getInt("fa_codigo"));                 
                fac.setFecha(rs.getDate("fa_fecha")); 
                fac.setUsuario(rs.getString(3));
                fac.setEstado(rs.getString("fa_estado")); 
                fac.setSubtotal(rs.getDouble("fa_subtotal")); 
                fac.setIva(rs.getDouble("fa_iva"));  
                fac.setTotal(rs.getDouble("fa_total"));                 
                list.add(fac);
            }
        } catch (Exception e) {
        }
        return list;
    }   
    
    @Override
    public List list() {
        //Metetodo que consulta la lista de Tr_Factura
        ArrayList<Tr_Factura> list = new ArrayList<>();
        String sql = "select * from tr_factura limit 10";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_Factura fac = new Tr_Factura();
                fac.setCodTransaccion(rs.getInt("fa_transaccion"));
                fac.setCodigo(rs.getInt("fa_codigo"));                 
                fac.setFecha(rs.getDate("fa_fecha")); 
                fac.setCodCliente(rs.getInt("fa_cliente"));  
                fac.setCodCaja(rs.getInt("fa_caja"));
                fac.setUsuario(rs.getString("fa_usuario"));
                fac.setSubtotal(rs.getDouble("fa_subtotal")); 
                fac.setIva(rs.getDouble("fa_iva"));  
                fac.setTotal(rs.getDouble("fa_total")); 
                fac.setEstado(rs.getString("fa_estado"));
                list.add(fac);
            }
        } catch (Exception e) {
        }
        return list;
    }  
    
    @Override
    public Tr_Factura list(int codigo) {
        //Metetodo que consulta la lista de Tr_Factura        
        String sql = "select * from tr_factura where fa_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                
                f.setCodTransaccion(rs.getInt("fa_transaccion"));
                f.setCodigo(rs.getInt("fa_codigo"));                 
                f.setFecha(rs.getDate("fa_fecha")); 
                f.setCodCliente(rs.getInt("fa_cliente")); 
                f.setCodCaja(rs.getInt("fa_caja"));
                f.setUsuario(rs.getString("fa_usuario"));
                f.setSubtotal(rs.getDouble("fa_subtotal")); 
                f.setIva(rs.getDouble("fa_iva"));  
                f.setTotal(rs.getDouble("fa_total")); 
                f.setEstado(rs.getString("fa_estado"));                
            }
        } catch (Exception e) {
        }
        return f;
    }

    @Override
    public int add(Tr_Factura factura) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();        
        //Obtenemos el ultimo Codigo Generado
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("tr_transaccion_monetaria");
        tabla.setCampo("tm_secuencial");
        if(comunes.getCodigo(tabla)>1)
        {
            factura.setCodTransaccion(comunes.getCodigo(tabla)-1); 
        }
        else
        {
            factura.setCodTransaccion(comunes.getCodigo(tabla)); 
        }               
        //Genera Nuevo Codigo        
        tabla.setTabla("tr_factura");
        tabla.setCampo("fa_codigo");
        factura.setCodigo(comunes.getCodigo(tabla));
        //Guardamos la Transaccion Monetaria
      
        Tr_TransaccionMonetaria transaccionMonetaria = factura.getTransaccionMonetaria();
        transaccionMonetaria.setDescripcion("FACTURA NRO:"+factura.getCodigo());
        if(factura.getEstado().equals("C")){
            transaccionMonetaria.setEstado("V");
        }
        else{
            transaccionMonetaria.setEstado("P");
        }
        //Transferencia
        if(factura.getTipoPago().equals("T")){
            transaccionMonetaria.setTipoPago("T");
        }
        //Factura Dividida
        if(factura.getTipoPago().equals("D")){
            transaccionMonetaria.setTipoPago("D");
        }
        
        Tr_TransaccionMonetariaDAO transaccionMonetariaDAO = new Tr_TransaccionMonetariaDAO();
        transaccionMonetariaDAO.add(transaccionMonetaria);
              
        //Fin Genera Codigo                      
        factura.setCodCliente(factura.getCodCliente());
        factura.setCodCaja(factura.getCodCaja());
        factura.setUsuario(factura.getUsuario());
        factura.setSubtotal(factura.getSubtotal());
        factura.setIva(factura.getIva());
        factura.setTotal(factura.getTotal());
        factura.setDetalleFactura(factura.getDetalleFactura());
        factura.setEstado(factura.getEstado());
        factura.setTipoPago(factura.getTipoPago());
        String fechaPago = "null";
        if (factura.getEstado().equals("C")){
             fechaPago = "NOW()";
        }
       
        String sql = "insert into tr_factura(fa_transaccion,fa_codigo,fa_fecha,fa_cliente,fa_caja,fa_usuario,fa_subtotal,fa_iva,fa_total,fa_estado,fa_fecha_pago,fa_tipo_pago) values ('"+
                factura.getCodTransaccion()+"','"+                  
                factura.getCodigo()+"',NOW(),'"+ 
                factura.getCodCliente()+"','"+ 
                factura.getCodCaja()+"','"+  
                factura.getUsuario()+"','"+  
                factura.getSubtotal()+"','"+
                factura.getIva()+"','"+
                factura.getTotal()+"','"+
                factura.getEstado()+"',"+
                fechaPago+",'"+
                factura.getTipoPago()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        List<Tr_DetalleFactura> detalle = factura.getDetalleFactura();
        for(int i=0; i<detalle.size();i++){
        sql = "insert into tr_detalle_factura(df_codigo,df_secuencial,df_producto,df_cantidad,df_valor,df_estado) values ('"+
                factura.getCodigo()+"','"+                  
                detalle.get(i).getSecuencial()+"','"+ 
                detalle.get(i).getCodigo()+"','"+   
                detalle.get(i).getCantidad()+"','"+
                detalle.get(i).getValor()+"','"+                
                detalle.get(i).getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            System.out.print("DAO.Tr_FacturaDAO.add():"+e);
        }
        Cl_Producto producto = new Cl_Producto();
        producto.setCodigo(detalle.get(i).getCodigo());
        producto.setCantidad(detalle.get(i).getCantidad());
        Cl_ProductoDAO productoDao = new Cl_ProductoDAO();
        if(producto.getCodigo()>0){
            productoDao.updateCantidad(producto);
        }
        
        }
        return factura.getCodigo();
    }    
    @Override
    public boolean pagar(int codigo) {
        String sql = "update  tr_factura set fa_estado = 'C', fa_fecha_pago = NOW() where fa_codigo ="+codigo+" and fa_estado = 'P'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            System.out.println("DAO.Tr_FacturaDAO.pagar():"+e);
        }
         sql = "update tr_transaccion_monetaria set tm_estado = 'V' where tm_secuencial = (select fa_transaccion from tr_factura where fa_codigo = "+codigo+" ) and tm_estado = 'P'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            System.out.println("DAO.Tr_FacturaDAO.pagar() tm:"+e);
        }
        
        return false;
    }
    @Override
    public boolean anular(int codigo) {
        String sql = "update  tr_factura set fa_estado = 'A', fa_fecha_pago = NOW() where fa_codigo ="+codigo+" and fa_estado = 'P'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            System.out.println("DAO.Tr_FacturaDAO.anular():"+e);
        }
        return false;
    }
    
}
