/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Model.Ad_Causa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import Interface.CausaCRUD;

/**
 *
 * @author gcueva
 */
public class Ad_CausaDAO implements CausaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Ad_Causa t = new Ad_Causa();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Causa> list = new ArrayList<>();
        String sql = "select * from ad_causa";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Causa pro = new Ad_Causa();
                pro.setCodigo(rs.getInt("ca_codigo"));                
                pro.setDescripcion(rs.getString("ca_descripcion"));                                
                pro.setFecha(rs.getDate("ca_fecha"));
                pro.setEstado(rs.getString("ca_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List listarCatalogo() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Causa> list = new ArrayList<>();
        String sql = "select * from ad_causa";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Causa pro = new Ad_Causa();
                pro.setCodigo(rs.getInt("ca_codigo"));                
                pro.setDescripcion(rs.getString("ca_descripcion"));                
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Ad_Causa list(int codigo) {
        //Metodo que consulta un Ad_Transaccion       
        String sql = "select * from ad_causa where ca_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                t.setCodigo(rs.getInt("ca_codigo"));                
                t.setDescripcion(rs.getString("ca_descripcion"));                               
                t.setFecha(rs.getDate("ca_fecha"));
                t.setEstado(rs.getString("ca_estado"));
                
            }
        } catch (Exception e) {
        }
        return t;
    }

    @Override
    public boolean add(Ad_Causa pro) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        String sql = "insert into ad_causa(ca_codigo,ca_descripcion,ca_fecha,ca_estado) values ('"+
                pro.getCodigo()+"','"+                
                pro.getDescripcion()+"',NOW(),'"+                
                pro.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_Causa tra) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        tra.setFecha(fecha);
        tra.setEstado("V");
        String sql = "update ad_causa set ca_descripcion='"+tra.getDescripcion()+"',"                              
                + "ca_estado='"+tra.getEstado()+"' where ca_codigo ="+tra.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from ad_causa where ca_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
