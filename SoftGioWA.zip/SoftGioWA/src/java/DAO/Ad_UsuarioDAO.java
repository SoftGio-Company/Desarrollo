/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.UsuarioCRUD;
import Model.Ad_Usuario;
import Model.Ad_Tabla;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Ad_UsuarioDAO implements UsuarioCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int r = 0;
    Ad_Usuario u = new Ad_Usuario();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Usuarios
        ArrayList<Ad_Usuario> list = new ArrayList<>();
        String sql = "select * from ad_usuario";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Usuario usr = new Ad_Usuario();
                usr.setCodigo(rs.getInt("us_codigo"));
                usr.setNombre(rs.getString("us_nombre"));
                usr.setLogin(rs.getString("us_login"));
                usr.setPassword(rs.getString("us_password"));
                usr.setFecha(rs.getDate("us_fecha"));
                usr.setEstado(rs.getString("us_estado"));
                list.add(usr);
            }
        } catch (Exception e) {
        }
        return list;
    }   

    @Override
    public Ad_Usuario list(int codigo) {
        //Metodo que consulta un Usuario        
        String sql = "select * from ad_usuario where us_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                u.setCodigo(rs.getInt("us_codigo"));
                u.setNombre(rs.getString("us_nombre"));
                u.setLogin(rs.getString("us_login"));
                u.setPassword(rs.getString("us_password"));
                u.setFecha(rs.getDate("us_fecha"));
                u.setEstado(rs.getString("us_estado"));
                
            }
        } catch (Exception e) {
        }
        return u;
    }

    @Override
    public boolean add(Ad_Usuario usr) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        usr.setFecha(fecha);
        usr.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("ad_usuario");
        tabla.setCampo("us_codigo");
        usr.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into ad_usuario(us_codigo,us_nombre,us_login,us_password,us_fecha,us_estado) values ('"+
                usr.getCodigo()+"','"+
                usr.getNombre()+"','"+
                usr.getLogin()+"','"+
                usr.getPassword()+"',NOW(),'"+                
                usr.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_Usuario usr) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        usr.setFecha(fecha);
        usr.setEstado("V");
        String sql = "update ad_usuario set us_nombre ='"+usr.getNombre()+"', "
                + "us_login='"+usr.getLogin()+"',"
                + "us_password='"+usr.getPassword()+"',"
                + "us_estado='"+usr.getEstado()+"' where us_codigo ="+usr.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from ad_usuario where us_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public int validar(Ad_Usuario usr) {
        String sql = "Select * from ad_usuario where us_login =? and us_password=?";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, usr.getLogin());
            ps.setString(2, usr.getPassword());
            rs = ps.executeQuery();
            r = 0;
            while(rs.next()){
                r = r + 1;
                usr.setCodigo(rs.getInt("us_codigo"));
                usr.setLogin(rs.getString("us_nombre"));  
            }
            if(r==1){
                return usr.getCodigo();
            }else{
                return 0;
            }
            
        } catch (Exception e) {
            return 0;
        }
        
    }
    
    
}
