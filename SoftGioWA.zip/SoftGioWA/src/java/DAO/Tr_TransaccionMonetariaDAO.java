/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.TransaccionMonetariaCRUD;
import Model.Ad_Tabla;
import Model.Tr_TransaccionMonetaria;
import Model.Tr_AperturaCaja;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Tr_TransaccionMonetariaDAO implements TransaccionMonetariaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Tr_TransaccionMonetaria t = new Tr_TransaccionMonetaria();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Tr_TransaccionMonetaria> list = new ArrayList<>();
        String sql = "select * from tr_transaccion_monetaria";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_TransaccionMonetaria tranMonet = new Tr_TransaccionMonetaria();
                tranMonet.setSecuencial(rs.getInt("tm_secuencial"));   
                tranMonet.setFecha(rs.getDate("tm_fecha"));
                tranMonet.setTransaccion(rs.getInt("tm_transaccion")); 
                tranMonet.setCausa(rs.getInt("tm_causa")); 
                tranMonet.setOficina(rs.getInt("tm_oficina"));
                tranMonet.setUsuario(rs.getInt("tm_usuario"));  
                tranMonet.setCaja(rs.getInt("tm_caja"));
                tranMonet.setValor(rs.getDouble("tm_valor"));  
                tranMonet.setCheque(rs.getDouble("tm_cheque"));
                tranMonet.setNumeroCheque(rs.getInt("tm_numero_cheque")); 
                tranMonet.setDescripcion(rs.getString("tm_descripcion")); 
                tranMonet.setEstado(rs.getString("tm_estado"));
                list.add(tranMonet);
            }
        } catch (Exception e) {
        }
        return list;
    }
      

   

    @Override
    public boolean add(Tr_TransaccionMonetaria tranMonet) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();
        tranMonet.setFecha(fecha);
        tranMonet.setEstado("V");
        Integer factor = 1;
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("tr_transaccion_monetaria");
        tabla.setCampo("tm_secuencial");
        tranMonet.setSecuencial(comunes.getCodigo(tabla));
        //Actualiza Saldo Caja
        Tr_AperturaCaja aperturaCaja = new Tr_AperturaCaja();   
        if(tranMonet.getTransaccion() == 200){
            factor = -1;
        }
        aperturaCaja.setOficina(tranMonet.getOficina());
        aperturaCaja.setUsuario(tranMonet.getUsuario());        
        aperturaCaja.setCaja(tranMonet.getCaja());
        aperturaCaja.setSaldoCaja(tranMonet.getValor()*factor);
        Tr_AperturaCajaDAO aperturaCajaDAO = new Tr_AperturaCajaDAO();
        //Fin Genera Codigo
        String sql = "insert into tr_transaccion_monetaria(tm_secuencial,tm_fecha,tm_transaccion,tm_causa,tm_oficina,tm_usuario,tm_caja,tm_valor,tm_cheque,tm_numero_cheque,tm_descripcion,tm_estado) values ('"+
                tranMonet.getSecuencial()+"',NOW(),'"+                 
                tranMonet.getTransaccion()+"','"+ 
                tranMonet.getCausa()+"','"+   
                tranMonet.getOficina()+"','"+   
                tranMonet.getUsuario()+"','"+   
                tranMonet.getCaja()+"','"+   
                tranMonet.getValor()+"','"+   
                tranMonet.getCheque()+"','"+   
                tranMonet.getNumeroCheque()+"','"+   
                tranMonet.getDescripcion()+"','"+   
                tranMonet.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        aperturaCajaDAO.updateSaldoCaja(aperturaCaja);
        return false;
    }    
    
}
