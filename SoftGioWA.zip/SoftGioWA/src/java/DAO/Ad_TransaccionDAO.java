/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.TransaccionCRUD;
import Model.Ad_Transaccion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Ad_TransaccionDAO implements TransaccionCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Ad_Transaccion t = new Ad_Transaccion();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Transaccion> list = new ArrayList<>();
        String sql = "select * from ad_transaccion";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Transaccion pro = new Ad_Transaccion();
                pro.setCodigo(rs.getInt("tr_codigo"));                
                pro.setDescripcion(rs.getString("tr_descripcion"));                                
                pro.setFecha(rs.getDate("tr_fecha"));
                pro.setEstado(rs.getString("tr_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List listarCatalogo() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Transaccion> list = new ArrayList<>();
        String sql = "select * from ad_transaccion";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Transaccion pro = new Ad_Transaccion();
                pro.setCodigo(rs.getInt("tr_codigo"));                
                pro.setDescripcion(rs.getString("tr_descripcion"));                
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Ad_Transaccion list(int codigo) {
        //Metodo que consulta un Ad_Transaccion       
        String sql = "select * from ad_transaccion where tr_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                t.setCodigo(rs.getInt("tr_codigo"));                
                t.setDescripcion(rs.getString("tr_descripcion"));                               
                t.setFecha(rs.getDate("tr_fecha"));
                t.setEstado(rs.getString("tr_estado"));
                
            }
        } catch (Exception e) {
        }
        return t;
    }

    @Override
    public boolean add(Ad_Transaccion pro) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();
        pro.setFecha(fecha);
        pro.setEstado("V");
        String sql = "insert into ad_transaccion(tr_codigo,tr_descripcion,tr_fecha,tr_estado) values ('"+
                pro.getCodigo()+"','"+                
                pro.getDescripcion()+"',NOW(),'"+                
                pro.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_Transaccion tra) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        tra.setFecha(fecha);
        tra.setEstado("V");
        String sql = "update ad_transaccion set tr_descripcion='"+tra.getDescripcion()+"',"                              
                + "pr_estado='"+tra.getEstado()+"' where tr_codigo ="+tra.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from ad_transaccion where tr_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
