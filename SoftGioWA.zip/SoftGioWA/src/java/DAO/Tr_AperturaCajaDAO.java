/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.AperturaCajaCRUD;
import Model.Ad_Tabla;
import Model.Tr_AperturaCaja;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 *
 * @author gcueva
 */
public class Tr_AperturaCajaDAO implements AperturaCajaCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Tr_AperturaCaja t = new Tr_AperturaCaja();
       
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Tr_AperturaCaja> list = new ArrayList<>();
        String sql = "select * from tr_apertura_caja where ac_estado = 'A'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_AperturaCaja aCaj = new Tr_AperturaCaja();
                aCaj.setCodigo(rs.getInt("ac_codigo"));
                aCaj.setFecha(rs.getDate("ac_fecha"));
                aCaj.setOficina(rs.getInt("ac_oficina"));  
                aCaj.setUsuario(rs.getInt("ac_usuario"));
                aCaj.setCaja(rs.getInt("ac_caja"));
                aCaj.setHoraInicio(rs.getTime("ac_hora_inicio"));
                aCaj.setHoraFin(rs.getTime("ac_hora_fin"));
                aCaj.setValorApertura(rs.getDouble("ac_valor_apertura"));
                aCaj.setSaldoCaja(rs.getDouble("ac_saldo_caja"));
                aCaj.setValorCierre(rs.getDouble("ac_valor_cierre"));
                aCaj.setEstado(rs.getString("ac_estado"));
                list.add(aCaj);
            }
        } catch (Exception e) {
        }
        return list;
    }
    @Override
    public List mensual() {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Tr_AperturaCaja> list = new ArrayList<>();
        String sql = "select * from tr_apertura_caja where MONTH(ac_fecha) = MONTH(CURRENT_DATE())AND YEAR(ac_fecha) = YEAR(CURRENT_DATE())";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_AperturaCaja aCaj = new Tr_AperturaCaja();
                aCaj.setCodigo(rs.getInt("ac_codigo"));
                aCaj.setFecha(rs.getDate("ac_fecha"));
                aCaj.setOficina(rs.getInt("ac_oficina"));  
                aCaj.setUsuario(rs.getInt("ac_usuario"));
                aCaj.setCaja(rs.getInt("ac_caja"));
                aCaj.setHoraInicio(rs.getTime("ac_hora_inicio"));
                aCaj.setHoraFin(rs.getTime("ac_hora_fin"));
                aCaj.setValorApertura(rs.getDouble("ac_valor_apertura"));
                aCaj.setSaldoCaja(rs.getDouble("ac_saldo_caja"));
                aCaj.setValorCierre(rs.getDouble("ac_valor_cierre"));
                aCaj.setEstado(rs.getString("ac_estado"));
                list.add(aCaj);
            }
        } catch (Exception e) {
        }
        return list;
    }
    @Override
    public List reporte(String fechaIni, String fechaFin) {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Tr_AperturaCaja> list = new ArrayList<>();
        String sql = "select * from tr_apertura_caja where ";
        if(!fechaIni.isEmpty() && !fechaFin.isEmpty())
        {            
            sql = sql + " Date(ac_fecha) BETWEEN '"+fechaIni+"' AND '"+fechaFin+"'";
        }
        else
        {
            sql = sql + " ac_fecha >= CURRENT_DATE()";
        }
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Tr_AperturaCaja aCaj = new Tr_AperturaCaja();
                aCaj.setCodigo(rs.getInt("ac_codigo"));
                aCaj.setFecha(rs.getDate("ac_fecha"));
                aCaj.setOficina(rs.getInt("ac_oficina"));  
                aCaj.setUsuario(rs.getInt("ac_usuario"));
                aCaj.setCaja(rs.getInt("ac_caja"));
                aCaj.setHoraInicio(rs.getTime("ac_hora_inicio"));
                aCaj.setHoraFin(rs.getTime("ac_hora_fin"));
                aCaj.setValorApertura(rs.getDouble("ac_valor_apertura"));
                aCaj.setSaldoCaja(rs.getDouble("ac_saldo_caja"));
                aCaj.setValorCierre(rs.getDouble("ac_valor_cierre"));
                aCaj.setEstado(rs.getString("ac_estado"));
                
                if(aCaj.getEstado().equals("C")){
                   int compareValue = aCaj.getSaldoCaja().compareTo(aCaj.getValorCierre());
                   if (compareValue == 0)
                       aCaj.setDescripcion("CUADRADO");
                   else if (compareValue < 0)
                      aCaj.setDescripcion("DESCUADRE POSITIVO");
                   else
                      aCaj.setDescripcion("DESCUADRE NEGATIVO");
                }
                else{
                    aCaj.setDescripcion("");
                }
                list.add(aCaj);
            }
        } catch (Exception e) {
        }
        return list;
    }
    @Override
    public boolean add(Tr_AperturaCaja apeCaja) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();        
        apeCaja.setFecha(fecha);
        apeCaja.setEstado("A");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("tr_apertura_caja");
        tabla.setCampo("ac_codigo");
        apeCaja.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into tr_apertura_caja(ac_codigo,ac_fecha,ac_oficina,ac_usuario,ac_caja,ac_hora_inicio,ac_valor_apertura,ac_saldo_caja,ac_estado) values ('"+
                apeCaja.getCodigo()+"',NOW(),'"+                 
                apeCaja.getOficina()+"','"+ 
                apeCaja.getUsuario()+"','"+   
                apeCaja.getCaja()+"',CURRENT_TIME(),'"+   
                apeCaja.getValorApertura()+"','"+
                apeCaja.getSaldoCaja()+"','"+
                apeCaja.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            return false;
        }        
        return true;
    }    
    @Override
    public boolean close(Tr_AperturaCaja apeCaja) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();        
        apeCaja.setFecha(fecha);
        apeCaja.setEstado("C");
        
        String sql = "update tr_apertura_caja set ac_estado ='"+apeCaja.getEstado()+"', ac_hora_fin = NOW(), ac_valor_cierre="+apeCaja.getValorCierre()+" "
                + "where ac_oficina ="+apeCaja.getOficina()+" and ac_usuario="+apeCaja.getUsuario()+" and ac_caja="+apeCaja.getCaja()+" and ac_estado = 'A'";
                
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            return false;
        }        
        return true;
    } 
    @Override
    public boolean update(Tr_AperturaCaja apeCaja) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();        
        apeCaja.setFecha(fecha);
        apeCaja.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("tr_apertura_caja");
        tabla.setCampo("ac_codigo");
        apeCaja.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into tr_apertura_caja(ac_codigo,ac_fecha,ac_oficina,ac_usuario,ac_hora_inicio,ac_valor_apertura,ac_estado) values ('"+
                apeCaja.getCodigo()+"',NOW(),'"+                 
                apeCaja.getOficina()+"','"+ 
                apeCaja.getUsuario()+"','"+   
                apeCaja.getHoraInicio()+"','"+   
                apeCaja.getValorApertura()+"','"+  
                apeCaja.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }    
    @Override
    public Tr_AperturaCaja validateOpen(Tr_AperturaCaja apeCaja) {
        //Metodo que consulta un Producto   
        t = new Tr_AperturaCaja();
        String sql = "select * from tr_apertura_caja where ac_oficina ="+apeCaja.getOficina()+                   
                     " and ac_caja="+apeCaja.getCaja()+" and ac_estado = 'A' and ac_fecha = current_date()";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                
                t.setCodigo(rs.getInt("ac_codigo"));
                t.setOficina(rs.getInt("ac_oficina"));
                t.setUsuario(rs.getInt("ac_usuario"));
                t.setCaja(rs.getInt("ac_caja"));                
                t.setFecha(rs.getDate("ac_fecha"));
                t.setEstado(rs.getString("ac_estado"));   
                t.setSaldoCaja(rs.getDouble("ac_saldo_caja"));
            }
        } catch (Exception e) {
        }
        return t;
    }
    @Override
    public boolean updateSaldoCaja(Tr_AperturaCaja apeCaja) {
        //Metodo que consulta un Producto   
        t = new Tr_AperturaCaja();
        String sql = "select * from tr_apertura_caja where ac_oficina ="+apeCaja.getOficina()+
                     " and ac_usuario="+apeCaja.getUsuario()+                     
                     " and ac_caja="+apeCaja.getCaja()+" and ac_fecha = current_date() and ac_estado = 'A'";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                                
                t.setSaldoCaja(rs.getDouble("ac_saldo_caja"));                              
            }
        } catch (Exception e) {
            return false;
        }
        sql = "update tr_apertura_caja set ac_saldo_caja ="+(t.getSaldoCaja()+apeCaja.getSaldoCaja())+ 
                     " where ac_oficina ="+apeCaja.getOficina()+
                     " and ac_usuario="+apeCaja.getUsuario()+                     
                     " and ac_caja="+apeCaja.getCaja()+" and ac_fecha = current_date() and ac_estado = 'A'";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
