/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Interface.MedicoCRUD;
import Model.Ad_Tabla;
import Model.Cl_Medico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Cl_MedicoDAO implements MedicoCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cl_Medico m = new Cl_Medico();
    
    @Override
    public List listar(String codigo, String id, String nombre, String apellido) {
        //Metetodo que consulta la lista de Usuarios
        if(codigo == null || (id != "" || nombre != "" || apellido != ""))
            codigo = "0";
        ArrayList<Cl_Medico> list = new ArrayList<>();
        String sql = "select  me_codigo,me_identificacion,concat_ws(' ',me_nombre,me_apellido),me_direccion,me_telefono,me_email from cl_medico where me_identificacion like '%"+id+"%' and me_nombre like'%"+nombre+"%' and me_apellido like '%"+apellido+"%' and me_codigo > "+codigo+"  order by me_codigo asc limit 10";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Cl_Medico med = new Cl_Medico();
                med.setCodigo(rs.getInt("me_codigo"));
                med.setIdentificacion(rs.getString("me_identificacion"));
                med.setNombre(rs.getString(3));                
                med.setDireccion(rs.getString("me_direccion"));
                med.setTelefono(rs.getString("me_telefono"));
                med.setEmail(rs.getString("me_email"));              
                list.add(med);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Cajas
        ArrayList<Cl_Medico> list = new ArrayList<>();
        String sql = "select * from cl_medico";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Cl_Medico med = new Cl_Medico();
                med.setCodigo(rs.getInt("me_codigo"));
                med.setNombre(rs.getString("me_nombre"));               
                med.setApellido(rs.getString("me_apellido")); 
                list.add(med);
            }
        } catch (Exception e) {
        }
        return list;
    }  

    @Override
    public Cl_Medico list(int codigo) {
        //Metodo que consulta un Usuario   
        Integer cod = new Integer(0);
        m = new Cl_Medico();        
        if(cod == codigo){            
            m.setCodigo(0);
            m.setIdentificacion("");
            m.setNombre("");
            m.setApellido("");
            m.setDireccion("");
            m.setTelefono("");
            m.setEmail("");
        }
        else{
        String sql = "select * from cl_medico where me_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){                
                m.setCodigo(rs.getInt("me_codigo"));
                m.setIdentificacion(rs.getString("me_identificacion"));
                m.setNombre(rs.getString("me_nombre"));
                m.setApellido(rs.getString("me_apellido"));
                m.setDireccion(rs.getString("me_direccion"));
                m.setTelefono(rs.getString("me_telefono"));
                m.setEmail(rs.getString("me_email"));
                m.setFecha(rs.getDate("me_fecha"));
                m.setEstado(rs.getString("me_estado"));                
            }
        } catch (Exception e) {
        }
        }
        return m;
    }
    @Override
    public Cl_Medico buscar(String cedula) {       
        String sql = "Select me_codigo,me_identificacion,me_nombre,me_apellido,me_direccion,me_telefono,me_email from me_cliente where me_identificacion ="+cedula;
        m = new Cl_Medico();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);           
            rs = ps.executeQuery();
            m.setIdentificacion(cedula);
           while(rs.next()){
            m.setCodigo(rs.getInt("me_codigo"));
            m.setIdentificacion(rs.getString("me_identificacion"));
            m.setNombre(rs.getString("me_nombre"));
            m.setApellido(rs.getString("me_apellido"));
            m.setDireccion(rs.getString("me_direccion"));
            m.setTelefono(rs.getString("me_telefono"));
            m.setEmail(rs.getString("me_email"));           
            }
            
        } catch (Exception e) {
            
        }
        return m;
    }

    @Override
    public boolean add(Cl_Medico med) {
        //Metodo que agrega un Usuario
        Date fecha = new Date();
        med.setFecha(fecha);
        med.setEstado("V");
        //Genera Nuevo Codigo
        Ad_ComunesDAO comunes = new Ad_ComunesDAO();
        Ad_Tabla tabla = new Ad_Tabla();
        tabla.setTabla("cl_medico");
        tabla.setCampo("me_codigo");
        med.setCodigo(comunes.getCodigo(tabla));
        //Fin Genera Codigo
        String sql = "insert into cl_medico(me_codigo,me_identificacion,me_nombre,me_apellido,me_direccion,me_telefono,me_email,me_fecha,me_estado) values ('"+
                med.getCodigo()+"','"+
                med.getIdentificacion()+"','"+
                med.getNombre()+"','"+
                med.getApellido()+"','"+
                med.getDireccion()+"','"+
                med.getTelefono()+"','"+ 
                med.getEmail()+"',NOW(),'"+ 
                med.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Cl_Medico med) {
        //Metodo que actualiza un Usuario
        Date fecha = new Date();
        med.setFecha(fecha);
        med.setEstado("V");
        String sql = "update cl_medico set me_identificacion ='"+med.getIdentificacion()+"', "
                + "me_nombre='"+med.getNombre()+"',"
                + "me_apellido='"+med.getApellido()+"',"
                + "me_direccion='"+med.getDireccion()+"',"
                + "me_telefono='"+med.getTelefono()+"',"
                + "me_email='"+med.getEmail()+"',"
                + "me_estado='"+med.getEstado()+"' where me_codigo ="+med.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from cl_medico where me_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
