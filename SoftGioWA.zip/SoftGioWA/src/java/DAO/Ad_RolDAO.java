/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Config.Conexion;
import Model.Ad_Rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import Interface.RolCRUD;

/**
 *
 * @author gcueva
 */
public class Ad_RolDAO implements RolCRUD{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Ad_Rol r = new Ad_Rol();
    @Override
    public List listar() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Rol> list = new ArrayList<>();
        String sql = "select * from ad_rol";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Rol pro = new Ad_Rol();
                pro.setCodigo(rs.getInt("ro_codigo"));                
                pro.setDescripcion(rs.getString("ro_descripcion"));                                
                pro.setFecha(rs.getDate("ro_fecha"));
                pro.setEstado(rs.getString("ro_estado"));
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    @Override
    public List listarCatalogo() {
        //Metetodo que consulta la lista de Ad_Transaccion
        ArrayList<Ad_Rol> list = new ArrayList<>();
        String sql = "select * from ad_rol";
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                Ad_Rol pro = new Ad_Rol();
                pro.setCodigo(rs.getInt("ro_codigo"));                
                pro.setDescripcion(rs.getString("ro_descripcion"));                
                list.add(pro);
            }
        } catch (Exception e) {
        }
        return list;
    }

    @Override
    public Ad_Rol list(int codigo) {
        //Metodo que consulta un Ad_Transaccion       
        String sql = "select * from ad_rol where ro_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            rs= ps.executeQuery();
            while(rs.next()){
                
                r.setCodigo(rs.getInt("ro_codigo"));                
                r.setDescripcion(rs.getString("ro_descripcion"));                               
                r.setFecha(rs.getDate("ro_fecha"));
                r.setEstado(rs.getString("ro_estado"));
                
            }
        } catch (Exception e) {
        }
        return r;
    }

    @Override
    public boolean add(Ad_Rol rol) {
        //Metodo que agrega un Ad_Transaccion
        Date fecha = new Date();
        rol.setFecha(fecha);
        rol.setEstado("V");
        String sql = "insert into ad_rol(ro_codigo,ro_descripcion,ro_fecha,ro_estado) values ('"+
                rol.getCodigo()+"','"+                
                rol.getDescripcion()+"',NOW(),'"+                
                rol.getEstado()+"')";
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean edit(Ad_Rol rol) {
        //Metodo que actualiza un Producto
        Date fecha = new Date();
        rol.setFecha(fecha);
        rol.setEstado("V");
        String sql = "update ad_rol set ro_descripcion='"+rol.getDescripcion()+"',"                              
                + "ro_estado='"+rol.getEstado()+"' where ro_codigo ="+rol.getCodigo();
        try {
            con = cn.getConnection();
            ps  = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }

    @Override
    public boolean eliminar(int codigo) {
        String sql = "delete  from ad_rol where ro_codigo ="+codigo;
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        } catch (Exception e) {
        }
        return false;
    }
    
}
