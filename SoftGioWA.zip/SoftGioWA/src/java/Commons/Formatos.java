/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Commons;

import java.text.DecimalFormat;

/**
 *
 * @author gcueva
 */
public class Formatos {
    
    public static String priceWithDecimal (Double price) {
    DecimalFormat formatter = new DecimalFormat("#########.00");
    return formatter.format(price);
    }

    public static String priceWithoutDecimal (Double price) {
    DecimalFormat formatter = new DecimalFormat("#########.##");
    return formatter.format(price);
    }
    
}
