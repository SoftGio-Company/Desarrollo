/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author gcueva
 */
public class Ad_Tabla {
    int codigo;
    String tabla;
    String campo;
    

    public Ad_Tabla() {
    }

    public Ad_Tabla(int codigo, String tabla, String campo) {
        this.codigo = codigo;
        this.tabla = tabla;
        this.campo = campo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTabla() {
        return tabla;
    }

    public void setTabla(String tabla) {
        this.tabla = tabla;
    }

    public String getCampo() {
        return campo;
    }

    public void setCampo(String campo) {
        this.campo = campo;
    }

    
      
    
}
