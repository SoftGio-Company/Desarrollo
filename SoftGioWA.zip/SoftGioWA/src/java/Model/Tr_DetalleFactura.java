/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author gcueva
 */
public class Tr_DetalleFactura {
    int codigo;
    int secuencial;    
    int producto;
    String descripcion;
    Double cantidad;    
    Double valor;          
    String estado;

    public Tr_DetalleFactura() {
    }

    public Tr_DetalleFactura(int codigo, int secuencial, int producto,String descripcion, Double cantidad, Double valor, String estado) {
        this.codigo = codigo;
        this.secuencial = secuencial;
        this.producto = producto;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.valor = valor;
        this.estado = estado;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getSecuencial() {
        return secuencial;
    }

    public void setSecuencial(int secuencial) {
        this.secuencial = secuencial;
    }

    public int getProducto() {
        return producto;
    }

    public void setProducto(int producto) {
        this.producto = producto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    
      
    
}
