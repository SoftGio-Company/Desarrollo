/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author gcueva
 */
public class Cl_Producto_His {
    int codigo;
    Date fecha;
    int codigoProducto;  
    Double precio;
    Double cantInicial;    
    Double cantIngreso; 
    Double cantEgreso; 
    String producto;

    public Cl_Producto_His() {
    }

    public Cl_Producto_His(int codigo, Date fecha, int codigoProducto, Double precio, Double cantInicial, Double cantIngreso, Double cantEgreso, String producto) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.codigoProducto = codigoProducto;
        this.precio = precio;
        this.cantInicial = cantInicial;
        this.cantIngreso = cantIngreso;
        this.cantEgreso = cantEgreso;
        this.producto = producto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Double getCantInicial() {
        return cantInicial;
    }

    public void setCantInicial(Double cantInicial) {
        this.cantInicial = cantInicial;
    }

    public Double getCantIngreso() {
        return cantIngreso;
    }

    public void setCantIngreso(Double cantIngreso) {
        this.cantIngreso = cantIngreso;
    }

    public Double getCantEgreso() {
        return cantEgreso;
    }

    public void setCantEgreso(Double cantEgreso) {
        this.cantEgreso = cantEgreso;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }
    
    
}
