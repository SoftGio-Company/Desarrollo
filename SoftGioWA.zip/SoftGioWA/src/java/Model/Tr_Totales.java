/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author gcueva
 */
public class Tr_Totales {    
    Date fecha;    
    int oficina;
    int usuario;
    int caja;
    Double ingEfectivo;
    Double ingTransferencia;
    Double ingCheque;    
    Double ingTotal; 
    Double egrEfectivo;
    Double egrTransferencia;
    Double egrCheque;    
    Double egrTotal;
    Double total;
    String descripcion;
    

    public Tr_Totales() {
    }

    public Tr_Totales(Date fecha, int oficina, int usuario, int caja, Double ingEfectivo, Double ingTransferencia, Double ingCheque, Double ingTotal, Double egrEfectivo, Double egrTransferencia, Double egrCheque, Double egrTotal, Double total, String descripcion) {
        this.fecha = fecha;
        this.oficina = oficina;
        this.usuario = usuario;
        this.caja = caja;
        this.ingEfectivo = ingEfectivo;
        this.ingTransferencia = ingTransferencia;
        this.ingCheque = ingCheque;
        this.ingTotal = ingTotal;
        this.egrEfectivo = egrEfectivo;
        this.egrTransferencia = egrTransferencia;
        this.egrCheque = egrCheque;
        this.egrTotal = egrTotal;
        this.total = total;
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getOficina() {
        return oficina;
    }

    public void setOficina(int oficina) {
        this.oficina = oficina;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public int getCaja() {
        return caja;
    }

    public void setCaja(int caja) {
        this.caja = caja;
    }

    public Double getIngEfectivo() {
        return ingEfectivo;
    }

    public void setIngEfectivo(Double ingEfectivo) {
        this.ingEfectivo = ingEfectivo;
    }

    public Double getIngTransferencia() {
        return ingTransferencia;
    }

    public void setIngTransferencia(Double ingTransferencia) {
        this.ingTransferencia = ingTransferencia;
    }

    public Double getIngCheque() {
        return ingCheque;
    }

    public void setIngCheque(Double ingCheque) {
        this.ingCheque = ingCheque;
    }

    public Double getIngTotal() {
        return ingTotal;
    }

    public void setIngTotal(Double ingTotal) {
        this.ingTotal = ingTotal;
    }

    public Double getEgrEfectivo() {
        return egrEfectivo;
    }

    public void setEgrEfectivo(Double egrEfectivo) {
        this.egrEfectivo = egrEfectivo;
    }

    public Double getEgrTransferencia() {
        return egrTransferencia;
    }

    public void setEgrTransferencia(Double egrTransferencia) {
        this.egrTransferencia = egrTransferencia;
    }

    public Double getEgrCheque() {
        return egrCheque;
    }

    public void setEgrCheque(Double egrCheque) {
        this.egrCheque = egrCheque;
    }

    public Double getEgrTotal() {
        return egrTotal;
    }

    public void setEgrTotal(Double egrTotal) {
        this.egrTotal = egrTotal;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    
    
    
      
    
}
