/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author gcueva
 */
public class Tr_TransaccionMonetaria {
    int secuencial;
    Date fecha;
    int transaccion;
    int causa;
    int oficina;
    int usuario;
    int caja;
    Double valor;
    Double cheque;
    int numeroCheque;
    String tipo;
    String descripcion;       
    String estado;
    String tipoPago;
    

    public Tr_TransaccionMonetaria() {
    }

    public Tr_TransaccionMonetaria(int secuencial, Date fecha, int transaccion, int causa, int oficina, int usuario, int caja, Double valor, Double cheque, int numeroCheque, String tipo ,String descripcion, String estado, String tipoPago) {
        this.secuencial = secuencial;
        this.fecha = fecha;
        this.transaccion = transaccion;
        this.causa = causa;
        this.oficina = oficina;
        this.usuario = usuario;
        this.caja = caja;
        this.valor = valor;
        this.cheque = cheque;
        this.numeroCheque = numeroCheque;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.estado = estado;
        this.tipoPago = tipoPago;
    }

    public int getSecuencial() {
        return secuencial;
    }

    public void setSecuencial(int secuencial) {
        this.secuencial = secuencial;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getTransaccion() {
        return transaccion;
    }

    public void setTransaccion(int transaccion) {
        this.transaccion = transaccion;
    }

    public int getCausa() {
        return causa;
    }

    public void setCausa(int causa) {
        this.causa = causa;
    }

    public int getOficina() {
        return oficina;
    }

    public void setOficina(int oficina) {
        this.oficina = oficina;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public int getCaja() {
        return caja;
    }

    public void setCaja(int caja) {
        this.caja = caja;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getCheque() {
        return cheque;
    }

    public void setCheque(Double cheque) {
        this.cheque = cheque;
    }

    public int getNumeroCheque() {
        return numeroCheque;
    }

    public void setNumeroCheque(int numeroCheque) {
        this.numeroCheque = numeroCheque;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    
    
      
    
}
