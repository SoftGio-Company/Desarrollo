/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;
import java.util.List;

/**
 *
 * @author gcueva
 */
public class Tr_Factura {
    int codTransaccion;
    int codigo;
    Date fecha;    
    int codCliente;     
    Double subtotal;
    Double iva;
    Double total;    
    String estado;    
    Tr_TransaccionMonetaria transaccionMonetaria;
    List<Tr_DetalleFactura> detalleFactura;
    
    public Tr_Factura() {
    }

    public Tr_Factura(int codTransaccion, int codigo, Date fecha, int codCliente, Double subtotal, Double iva, Double total, String estado, Tr_TransaccionMonetaria transaccionMonetaria, List<Tr_DetalleFactura> detalleFactura) {
        this.codTransaccion = codTransaccion;
        this.codigo = codigo;
        this.fecha = fecha;
        this.codCliente = codCliente;
        this.subtotal = subtotal;
        this.iva = iva;
        this.total = total;
        this.estado = estado;
        this.transaccionMonetaria = transaccionMonetaria;
        this.detalleFactura = detalleFactura;
    }

    public int getCodTransaccion() {
        return codTransaccion;
    }

    public void setCodTransaccion(int codTransaccion) {
        this.codTransaccion = codTransaccion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.subtotal = subtotal;
    }

    public Double getIva() {
        return iva;
    }

    public void setIva(Double iva) {
        this.iva = iva;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Tr_TransaccionMonetaria getTransaccionMonetaria() {
        return transaccionMonetaria;
    }

    public void setTransaccionMonetaria(Tr_TransaccionMonetaria transaccionMonetaria) {
        this.transaccionMonetaria = transaccionMonetaria;
    }

    public List<Tr_DetalleFactura> getDetalleFactura() {
        return detalleFactura;
    }

    public void setDetalleFactura(List<Tr_DetalleFactura> detalleFactura) {
        this.detalleFactura = detalleFactura;
    }

       
}
