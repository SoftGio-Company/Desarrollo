/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Time;
import java.util.Date;

/**
 *
 * @author gcueva
 */
public class Tr_AperturaCaja {
    int codigo;
    Date fecha;
    int oficina;
    int usuario;    
    int caja;
    Time horaInicio;
    Time horaFin;
    Double valorApertura;
    Double saldoCaja;
    Double valorCierre;       
    String estado;
    String descripcion;

    public Tr_AperturaCaja() {
    }

    public Tr_AperturaCaja(int codigo, Date fecha, int oficina, int usuario, int caja, Time horaInicio, Time horaFin, Double valorApertura, Double saldoCaja, Double valorCierre, String estado, String descripcion) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.oficina = oficina;
        this.usuario = usuario;        
        this.caja = caja;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.valorApertura = valorApertura;
        this.saldoCaja = saldoCaja;
        this.valorCierre = valorCierre;
        this.estado = estado;
        this.descripcion = descripcion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getOficina() {
        return oficina;
    }

    public void setOficina(int oficina) {
        this.oficina = oficina;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public int getCaja() {
        return caja;
    }

    public void setCaja(int caja) {
        this.caja = caja;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

    public Double getValorApertura() {
        return valorApertura;
    }

    public void setValorApertura(Double valorApertura) {
        this.valorApertura = valorApertura;
    }

    public Double getSaldoCaja() {
        return saldoCaja;
    }

    public void setSaldoCaja(Double saldoCaja) {
        this.saldoCaja = saldoCaja;
    }

    public Double getValorCierre() {
        return valorCierre;
    }

    public void setValorCierre(Double valorCierre) {
        this.valorCierre = valorCierre;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    
    
}
