/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_UsuarioRol;
import Model.Tr_AperturaCaja;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface UsuarioRolCRUD {
    public List listar();
    public Ad_UsuarioRol list(int usuario);
    public boolean add(Ad_UsuarioRol usr);
    public boolean edit(Ad_UsuarioRol usr);
    public boolean eliminar(int usuario);
    public int validar(Ad_UsuarioRol usr);
    public List listarCajas(Ad_UsuarioRol usr);
}
