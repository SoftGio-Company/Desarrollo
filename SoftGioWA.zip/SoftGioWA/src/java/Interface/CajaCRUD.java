/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_Caja;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface CajaCRUD {
    public List listar();
    public List listarCajaUsuario(int oficina,int usuario);
    public List listarCajaAbiertaUsuario(int oficina,int usuario);
    public List listarCajas();
    public Ad_Caja list(int codigo);
    public boolean add(Ad_Caja caj);
    public boolean edit(Ad_Caja caj);
    public boolean eliminar(int codigo);
    public int validar(Ad_Caja usr);
}
