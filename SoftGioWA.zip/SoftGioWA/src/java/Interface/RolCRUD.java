/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_Rol;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface RolCRUD {
    public List listar();
    public List listarCatalogo();
    public Ad_Rol list(int codigo);
    public boolean add(Ad_Rol rol);
    public boolean edit(Ad_Rol rol);
    public boolean eliminar(int codigo);
    
    
}
