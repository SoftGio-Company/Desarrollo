/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_Oficina;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface OficinaCRUD {
    public List listar();
    public List listarCatalogo();
    public Ad_Oficina list(int codigo);
    public boolean add(Ad_Oficina ofi);
    public boolean edit(Ad_Oficina ofi);
    public boolean eliminar(int codigo);
    
    
}
