/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Tr_Factura;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface FacturaCRUD {
    public List listar(String codigo, String cedula, String fechaIni, String fechaFin);    
    public List list();    
    public Tr_Factura list(int codigo);
    public int add(Tr_Factura fac);
    //public boolean edit(Tr_Factura fac);
    //public boolean eliminar(int codigo);
    
    
}
