/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_Transaccion;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface TransaccionCRUD {
    public List listar();
    public List listarCatalogo();
    public Ad_Transaccion list(int codigo);
    public boolean add(Ad_Transaccion tra);
    public boolean edit(Ad_Transaccion tra);
    public boolean eliminar(int codigo);
    
    
}
