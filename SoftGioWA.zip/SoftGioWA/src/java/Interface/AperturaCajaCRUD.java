/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Tr_AperturaCaja;
import java.util.List;


/**
 *
 * @author gcueva
 */
public interface AperturaCajaCRUD {
    public List listar();
    public boolean add(Tr_AperturaCaja apeCaja);
    public boolean close(Tr_AperturaCaja apeCaja);
    public boolean update(Tr_AperturaCaja apeCaja);  
    public Tr_AperturaCaja validateOpen(Tr_AperturaCaja apeCaja); 
    public boolean updateSaldoCaja(Tr_AperturaCaja apeCaja); 
    
    
}
