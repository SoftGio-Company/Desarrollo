/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_Causa;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface CausaCRUD {
    public List listar();
    public List listarCatalogo();
    public Ad_Causa list(int codigo);
    public boolean add(Ad_Causa tra);
    public boolean edit(Ad_Causa tra);
    public boolean eliminar(int codigo);
    
    
}
