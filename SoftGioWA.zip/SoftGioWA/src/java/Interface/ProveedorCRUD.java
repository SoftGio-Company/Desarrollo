/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Cl_Proveedor;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface ProveedorCRUD {
    public List listar();
    public Cl_Proveedor list(int codigo);
    public Cl_Proveedor buscar(String cedula);
    public boolean add(Cl_Proveedor pro);
    public boolean edit(Cl_Proveedor pro);
    public boolean eliminar(int codigo);
    
    
}
