/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Cl_Cliente;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface ClienteCRUD {
    public List listar(String codigo,String id, String nombre, String apellido);
    public Cl_Cliente list(int codigo);
    public Cl_Cliente buscar(String cedula);
    public boolean add(Cl_Cliente cli);
    public boolean edit(Cl_Cliente cli);
    public boolean eliminar(int codigo);
    
    
}
