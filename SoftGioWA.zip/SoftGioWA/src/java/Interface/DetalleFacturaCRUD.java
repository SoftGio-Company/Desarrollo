/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Tr_DetalleFactura;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface DetalleFacturaCRUD {
    public List listar();
    public List listarDetalle();
    public List listarDetalle(int codigo);
    //public Tr_DetalleFactura list(int codigo);
    public boolean add(Tr_DetalleFactura detF);
    //public boolean edit(Tr_DetalleFactura detF);
    //public boolean eliminar(int codigo);
    
    
}
