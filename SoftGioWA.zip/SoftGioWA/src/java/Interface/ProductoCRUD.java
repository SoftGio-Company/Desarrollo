/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Cl_Producto;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface ProductoCRUD {
    public List listar(String codigo, String codigoPro, String nombrePro);
    public List listarProductos(String codigo, String codigoPro, String nombrePro);
    public Cl_Producto list(int codigo);
    public Cl_Producto buscar(String producto);
    public boolean add(Cl_Producto pro);
    public boolean edit(Cl_Producto pro);
    public boolean eliminar(int codigo);
    public boolean updateCantidad(Cl_Producto pro);
    
}
