/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Ad_Tabla;
import Model.Cl_Cliente;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface ComunesCRUD {
 
    public int getCodigo(Ad_Tabla tabla);
    public String getDescripcion(Ad_Tabla tabla);
    public List catalogo(String tabla);
    
}
