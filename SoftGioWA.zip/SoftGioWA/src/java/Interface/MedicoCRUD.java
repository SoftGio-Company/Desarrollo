/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Model.Cl_Medico;
import java.util.List;

/**
 *
 * @author gcueva
 */
public interface MedicoCRUD {
    public List listar(String codigo,String id, String nombre, String apellido);
    public List listar();
    public Cl_Medico list(int codigo);
    public Cl_Medico buscar(String cedula);
    public boolean add(Cl_Medico med);
    public boolean edit(Cl_Medico med);
    public boolean eliminar(int codigo);
    
    
}
