CREATE DATABASE  IF NOT EXISTS `softgio` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `softgio`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: softgio
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cl_proveedor`
--

DROP TABLE IF EXISTS `cl_proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cl_proveedor` (
  `pr_codigo` int(11) NOT NULL,
  `pr_identificacion` varchar(15) NOT NULL,
  `pr_nombre` varchar(32) NOT NULL,
  `pr_direccion` varchar(64) NOT NULL,
  `pr_telefono` varchar(20) NOT NULL,
  `pr_email` varchar(32) NOT NULL,
  `pr_fecha` datetime DEFAULT NULL,
  `pr_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cl_proveedor`
--

LOCK TABLES `cl_proveedor` WRITE;
/*!40000 ALTER TABLE `cl_proveedor` DISABLE KEYS */;
INSERT INTO `cl_proveedor` VALUES (1,'1720693215001','PRONACA','TUMBACO GRANJA AGRICOLA','0984523918','ventas@pronaca.com','2020-08-26 11:42:05','V'),(2,'12321321312','Alberto','Pomasqui','0956424222','albert@gmail.com','2020-09-29 23:23:30','V'),(3,'0701210312','Japon','San Carlos','1234333','pato@gmail.com','2020-09-29 23:27:43','V'),(4,'1720693215','SoftGio','Cumbaya','2345678','infosoftgio@gmail.com','2020-10-13 18:06:16','V');
/*!40000 ALTER TABLE `cl_proveedor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-14 23:58:02
