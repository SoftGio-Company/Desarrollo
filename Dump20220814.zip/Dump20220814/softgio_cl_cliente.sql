CREATE DATABASE  IF NOT EXISTS `softgio` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `softgio`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: softgio
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cl_cliente`
--

DROP TABLE IF EXISTS `cl_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cl_cliente` (
  `cl_codigo` int(11) NOT NULL,
  `cl_identificacion` varchar(15) NOT NULL,
  `cl_nombre` varchar(32) DEFAULT NULL,
  `cl_apellido` varchar(20) DEFAULT NULL,
  `cl_direccion` varchar(64) DEFAULT NULL,
  `cl_telefono` varchar(10) DEFAULT NULL,
  `cl_fecha` datetime DEFAULT NULL,
  `cl_estado` char(1) DEFAULT NULL,
  `cl_email` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cl_cliente`
--

LOCK TABLES `cl_cliente` WRITE;
/*!40000 ALTER TABLE `cl_cliente` DISABLE KEYS */;
INSERT INTO `cl_cliente` VALUES (1,'9999999999','Consumidor','Final','Tumbaco','2593954','2020-03-25 12:54:43','V','consumidor.final@frigocarito.com'),(2,'1720693215','Giovanny','Cueva','Puembo_Calle_24_de_Mayo_y_Linea_Ferrea','2390477','2020-03-25 12:58:02','V','jhonpat1985@hotmail.com'),(3,'1710576594','Marcia ','Espinoza','Tumbaco','0995368711','2020-03-26 20:23:02','V','frigocarito@gmail.com'),(4,'1719345199','Carolina ','Cardenas','Puembo Calle 24 de Mayo y Linea Ferrea','2390477','2020-03-26 20:28:13','V','karocardenas_30@hotmail.com'),(5,'0701210312','Cesar Tadeo','Cueva Paladines','San Carlos El Triunfo Calle 26 de Agosto Oe14-50','0992774162','2020-03-29 23:37:45','V','cesartadeo.cueva@gmail.com'),(9,'1723923528','Ronaldo','Espinoza','Puembo Calle 24 de Mayo y Estadio','2391702','2020-04-06 17:14:18','V','ronaldogato_2304@hotmail.com'),(12,'1720693219','Amanda','Lopez','Puembo','2539654','2020-10-26 15:35:27','V','amanda@hotmail.com'),(13,'0701210322','Fermanda','Rojas','Los valles','0985452369','2020-10-26 15:36:27','V','fer_rojas@hotmail.com'),(14,'0701210318','Juanito','Casas','La florida','2365945','2020-10-26 15:37:24','V','juanito@gmail.com'),(15,'0701210318','Alberto Segundo','Granja Cajas','Puembo Calle 24 de Mayo y Linea Ferrea','2539654','2020-11-06 11:08:38','V','albert_puembo@gmail.com'),(16,'1720690000','Fernando','Cueva','Puembo Calle 24 de Mayo y Linea Ferrea','2390477','2020-11-09 10:24:02','V','ronaldogato2304@hotmail.com'),(17,'1751504513','Jessica  Stefania','Garcia Espinoza','Puembo Calle Manuel Burbano','0998920362','2020-11-09 20:09:29','V','stefannia3012@outlook.com'),(18,'1721787404','Armando ','Espinoza','Quito','2593954','2020-11-09 20:47:40','V','Armando @hotmail.com'),(19,'1758001810','Paula','Cueva','Puembo Calle 24 de Mayo y Linea Ferrea','2390477','2021-02-04 15:41:14','V','paula.cueva@pachamama.com');
/*!40000 ALTER TABLE `cl_cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-14 23:57:54
