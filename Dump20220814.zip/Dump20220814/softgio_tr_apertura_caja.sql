CREATE DATABASE  IF NOT EXISTS `softgio` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `softgio`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: softgio
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tr_apertura_caja`
--

DROP TABLE IF EXISTS `tr_apertura_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tr_apertura_caja` (
  `ac_codigo` int(11) NOT NULL,
  `ac_fecha` date NOT NULL,
  `ac_oficina` int(11) NOT NULL,
  `ac_usuario` int(11) NOT NULL,
  `ac_caja` int(11) NOT NULL,
  `ac_hora_inicio` time NOT NULL,
  `ac_hora_fin` time DEFAULT NULL,
  `ac_valor_apertura` decimal(8,2) DEFAULT NULL,
  `ac_saldo_caja` decimal(8,2) DEFAULT NULL,
  `ac_valor_cierre` decimal(8,2) DEFAULT NULL,
  `ac_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr_apertura_caja`
--

LOCK TABLES `tr_apertura_caja` WRITE;
/*!40000 ALTER TABLE `tr_apertura_caja` DISABLE KEYS */;
INSERT INTO `tr_apertura_caja` VALUES (1,'2020-11-25',1,12,1,'12:58:36','17:44:49',15.00,323.25,1583.43,'C'),(2,'2021-02-19',1,12,1,'17:46:59','07:03:47',50.00,323.25,70.28,'C'),(3,'2021-02-20',1,12,1,'07:04:20','00:04:50',25.00,323.25,47.50,'C'),(4,'2021-02-21',1,13,2,'23:55:51','00:04:03',50.00,908.50,109.00,'C'),(5,'2021-02-22',1,12,1,'17:28:10','12:07:45',50.00,323.25,150.00,'C'),(6,'2021-02-25',1,12,1,'16:46:09',NULL,58.00,323.25,NULL,'A'),(7,'2021-02-26',1,13,2,'11:47:02',NULL,85.00,908.50,NULL,'A'),(8,'2021-04-24',1,12,1,'11:41:11',NULL,150.00,323.25,NULL,'A');
/*!40000 ALTER TABLE `tr_apertura_caja` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-14 23:58:05
