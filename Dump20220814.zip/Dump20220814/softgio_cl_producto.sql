CREATE DATABASE  IF NOT EXISTS `softgio` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `softgio`;
-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: softgio
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cl_producto`
--

DROP TABLE IF EXISTS `cl_producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cl_producto` (
  `pr_codigo` int(11) NOT NULL,
  `pr_producto` varchar(15) NOT NULL,
  `pr_descripcion` varchar(32) DEFAULT NULL,
  `pr_precio` decimal(8,2) DEFAULT NULL,
  `pr_cantidad` decimal(8,2) NOT NULL,
  `pr_fecha` datetime DEFAULT NULL,
  `pr_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cl_producto`
--

LOCK TABLES `cl_producto` WRITE;
/*!40000 ALTER TABLE `cl_producto` DISABLE KEYS */;
INSERT INTO `cl_producto` VALUES (1,'P001','Pollo Completo Libra',1.65,-74.00,'2020-11-09 20:32:32','V'),(2,'P002','Pollo Vacio Libra ',1.20,-13.00,'2020-12-21 15:39:55','V'),(3,'P003','Alas y Espaldilla',1.22,86.00,'2020-12-21 15:40:42','V'),(4,'P004','Muslos',1.14,98.00,'2020-12-21 15:41:29','V'),(5,'P005','Pechuga',1.53,100.00,'2020-12-21 15:42:44','V'),(6,'P006','Piernas y Muslos',1.26,100.00,'2020-12-21 15:43:34','V'),(7,'P007','Piernitas',1.55,100.00,'2020-12-21 15:44:20','V'),(8,'P008','Higado',0.48,100.00,'2020-12-21 15:45:53','V'),(9,'P009','Higado y Molleja',0.90,100.00,'2020-12-21 15:46:31','V'),(10,'P010','Molleja',1.70,100.00,'2020-12-21 15:47:06','V'),(11,'P011','Alitas',1.90,100.00,'2020-12-21 15:48:13','V'),(12,'P012','Gallina',5.50,100.00,'2020-12-21 15:49:41','V'),(13,'P013','Patas y Cabezas Blanca',0.50,100.00,'2020-12-21 15:50:14','V'),(14,'P014','Patas y Cabezas Amarillas ',0.65,100.00,'2020-12-21 15:50:50','V'),(15,'P015','Hueso de Pollo',0.65,100.00,'2020-12-21 15:53:21','V'),(16,'A001','Canela 10g ',0.35,100.00,'2020-12-21 16:01:52','V'),(17,'A002','Comino Molido 25g',0.25,100.00,'2020-12-21 16:02:35','V'),(18,'A003','Comino Molido 50g',0.55,100.00,'2020-12-21 16:03:12','V'),(19,'A004','Sabora 25g',0.25,100.00,'2020-12-21 16:03:52','V'),(20,'A005','Sabora 50g',0.43,100.00,'2020-12-21 16:04:20','V'),(21,'A006','Ajo 25g',0.16,100.00,'2020-12-21 16:04:53','V'),(22,'A007','Ajo 50g',0.55,100.00,'2020-12-21 16:05:56','V'),(23,'A008','Aji 50g',0.40,100.00,'2020-12-21 16:06:43','V'),(24,'A009','Chimichurri 215g',0.65,100.00,'2020-12-21 16:07:28','V'),(25,'A010','Mega Sazon 200g',1.25,100.00,'2020-12-21 16:08:20','V'),(26,'A011','Mani 200g ',1.65,100.00,'2020-12-21 16:08:53','V'),(27,'A012','AliÃ±o 215g',0.65,100.00,'2020-12-21 16:09:29','V'),(28,'A013','AliÃ±o 430g',1.15,100.00,'2020-12-21 16:10:08','V'),(29,'A014','Mani 25g',0.25,100.00,'2020-12-21 16:10:53','V'),(30,'A015','Anis Comun 43g',1.25,100.00,'2020-12-21 16:12:41','V'),(31,'A016','Menta 37.5g ',1.25,100.00,'2020-12-21 16:13:33','V'),(32,'A017','Cedron 37.5g',1.25,100.00,'2020-12-21 16:14:14','V'),(33,'A018','Horchata 37.5g ',1.25,100.00,'2020-12-21 16:14:52','V'),(34,'A019','Canela Caja',1.25,100.00,'2020-12-21 16:16:18','V'),(35,'A020','Hierba Luisa Caja',1.25,100.00,'2020-12-21 16:16:51','V'),(36,'A021','Toronjil Caja',1.25,100.00,'2020-12-21 16:17:33','V'),(37,'A022','Oregano Caja',1.25,100.00,'2020-12-21 16:18:04','V'),(38,'H001','Huevos de Coodornis',1.50,75.00,'2020-12-21 16:19:11','V'),(39,'H002','Huevos PequeÃ±os',3.40,96.00,'2020-12-21 16:19:38','V'),(40,'H003','Huevos Grandes',3.60,95.00,'2020-12-21 16:20:01','V'),(41,'V001','Azucar 500g',0.55,100.00,'2020-12-21 16:22:01','V'),(42,'V002','Azucar 2LB',1.05,100.00,'2020-12-21 16:22:35','V'),(43,'V003','Azucar 4LB',2.05,100.00,'2020-12-21 16:23:13','V'),(44,'V004','Aceite 560ml',1.00,100.00,'2020-12-21 16:23:58','V'),(45,'V005','Aceite Oro 1LT',1.70,100.00,'2020-12-21 16:24:28','V'),(46,'C001','Carne de Chancho',1.50,95.00,'2020-12-21 16:26:23','V'),(47,'C002','Hueso de Chancho',1.85,100.00,'2020-12-21 16:26:51','V'),(48,'C003','Chuleta de Chancho',1.85,100.00,'2020-12-21 16:27:36','V');
/*!40000 ALTER TABLE `cl_producto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-14 23:57:59
